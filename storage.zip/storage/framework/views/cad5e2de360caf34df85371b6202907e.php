<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight flex items-center">
                <button onclick="window.history.back();" class="px-4 py-2 text-blue-600 dark:text-blue-400 rounded-md hover:text-blue-700 dark:hover:text-blue-300">
                    ←
                </button>
                <?php echo e(__('Details')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="flex justify-center items-center p-6">
        <div class="w-full max-w-4xl bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Customer Details -->
                <div>
                    <h3 class="font-semibold text-gray-800 dark:text-gray-200 mb-2">Customer Details</h3>
                    <?php if (isset($component)) { $__componentOriginal0ff1ee8966084a5d418f848c5e125b44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ff1ee8966084a5d418f848c5e125b44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ff1ee8966084a5d418f848c5e125b44)): ?>
<?php $attributes = $__attributesOriginal0ff1ee8966084a5d418f848c5e125b44; ?>
<?php unset($__attributesOriginal0ff1ee8966084a5d418f848c5e125b44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ff1ee8966084a5d418f848c5e125b44)): ?>
<?php $component = $__componentOriginal0ff1ee8966084a5d418f848c5e125b44; ?>
<?php unset($__componentOriginal0ff1ee8966084a5d418f848c5e125b44); ?>
<?php endif; ?>
                    <form method="POST" action="<?php echo e(route('customer.order')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="grid gap-4">
                            <div>
                                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'customer_id','value' => __('Customer Name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'customer_id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Customer Name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                                    <select id="customer_id" name="customer_id" class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-indigo-300 bg-gray-100 dark:bg-gray-700 dark:text-white">
                                        <option value="">Select Customer</option>
                                        <?php $__currentLoopData = $consignee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>">(Main) <?php echo e($customer->first_name); ?> <?php echo e($customer->last_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($customer->company_name != null): ?>
                                                <option value="<?php echo e($customer->sub_account_number); ?>">(Sub) <?php echo e($customer->company_name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($customer->sub_account_number); ?>">(Sub) <?php echo e($customer->first_name); ?> <?php echo e($customer->last_name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                            </div>

                            <div>
                                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'customer_no','value' => __('Customer Number')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'customer_no','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Customer Number'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                                <input type="text" id="customer_no" name="customer_no" class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-indigo-300 bg-gray-100 dark:bg-gray-700 dark:text-white" maxlength="11" pattern="\d{1,11}" oninput="this.value = this.value.replace(/\D/g, '').slice(0, 11)">
                            </div>

                            <div>
                                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'status','value' => __('Status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'status','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                                <select id="status" name="status" class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-indigo-300 bg-gray-100 dark:bg-gray-700 dark:text-white" required>
                                    <option value="">Select Status</option>
                                    <option value="Shipper">Shipper</option>
                                    <option value="Consignee">Consignee</option>
                                </select>
                            </div>
                        </div>
                </div>

                <!-- Receiver Details -->
                <div>
                    <h3 class="font-semibold text-gray-800 dark:text-gray-200 mb-2">Receiver Details</h3>
                    <div class="grid gap-4">
                        <div>
                            <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'receiver_name','value' => __('Receiver Name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'receiver_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Receiver Name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                            <div class="flex gap-2">
                                <select id="receiver_name" name="receiver_name" class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-indigo-300 bg-gray-100 dark:bg-gray-700 dark:text-white">
                                    <option value="">Select Receiver Name</option>
                                </select>
                                <button id="openReceiverModal" type="button" class="px-4 py-2 bg-indigo-500 dark:bg-indigo-600 text-white rounded-md">Select</button>
                            </div>
                        </div>

                        <div>
                            <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'receiver_no','value' => __('Receiver Number')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'receiver_no','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Receiver Number'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                            <input type="text" id="receiver_no" name="receiver_no" class="w-full px-4 py-2 border rounded-md focus:ring focus:ring-indigo-300 bg-gray-100 dark:bg-gray-700 dark:text-white" maxlength="11" pattern="\d{1,11}" oninput="this.value = this.value.replace(/\D/g, '').slice(0, 11)">
                        </div>
                    </div>
                </div>
            </div>
            <div id="receiverModal" class="fixed inset-0 z-50 hidden flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white p-6 rounded-lg w-full max-w-lg dark:bg-gray-800">
                    <h2 class="text-lg font-semibold mb-4">Select Receiver</h2>

                    <!-- Search Bar -->
                    <input type="text" id="searchReceiver" placeholder="Search by name or ID..."
                        class="w-full p-2 mb-2 border rounded-md dark:bg-gray-700 dark:text-white"
                        onkeyup="filterReceivers()">

                    <!-- Receiver Table -->
                    <table class="w-full border-collapse border border-gray-300">
                        <thead>
                            <tr class="bg-gray-100 dark:bg-gray-700 text-black dark:text-white">
                                <th class="border p-2">ID</th>
                                <th class="border p-2">First Name</th>
                                <th class="border p-2">Last Name</th>
                            </tr>
                        </thead>
                        <tbody id="receiverTableBody">
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-500 receiver-row"
                                onclick="selectReceiver('<?php echo e($customer->id); ?>', '<?php echo e($customer->first_name); ?> <?php echo e($customer->last_name); ?>', '<?php echo e($customer->phonenum); ?>')">
                                <td class="border p-2"><?php echo e($customer->id); ?></td>
                                <td class="border p-2"><?php echo e($customer->first_name); ?></td>
                                <td class="border p-2"><?php echo e($customer->last_name); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <!-- Pagination Controls -->
                    <div class="flex justify-between items-center mt-4">
                        <button id="prevPage" class="px-4 py-2 bg-blue-500 text-white rounded-md" onclick="changePage(-1)">Previous</button>
                        <span id="paginationInfo" class="text-sm text-gray-700 dark:text-gray-300"></span>
                        <button id="nextPage" class="px-4 py-2 bg-blue-500 text-white rounded-md" onclick="changePage(1)">Next</button>
                    </div>

                    <!-- Close Button -->
                    <div class="flex justify-end mt-4">
                        <button id="closeReceiverModal" class="px-4 py-2 bg-gray-500 text-white rounded-md">Close</button>
                    </div>
                </div>
            </div>

            <div class="mt-6">
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'justify-center w-full gap-2','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'justify-center w-full gap-2','type' => 'submit']); ?>
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-shopping-cart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                    <span><?php echo e(__('Proceed')); ?></span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            </div>
            </form>
        </div>
    </div>
    <script>
        let currentPage = 1;
        const rowsPerPage = 5; // Adjust for more or fewer rows
        const receiverRows = document.querySelectorAll(".receiver-row");
        const totalRows = receiverRows.length;
        const totalPages = Math.ceil(totalRows / rowsPerPage);

        function showPage(page) {
            receiverRows.forEach((row, index) => {
                row.style.display = (index >= (page - 1) * rowsPerPage && index < page * rowsPerPage) ? "" : "none";
            });

            document.getElementById("paginationInfo").innerText = `Page ${page} of ${totalPages}`;
            document.getElementById("prevPage").disabled = page === 1;
            document.getElementById("nextPage").disabled = page === totalPages;
        }

        function changePage(direction) {
            if ((direction === -1 && currentPage > 1) || (direction === 1 && currentPage < totalPages)) {
                currentPage += direction;
                showPage(currentPage);
            }
        }

        function filterReceivers() {
            const searchValue = document.getElementById("searchReceiver").value.toLowerCase();
            receiverRows.forEach(row => {
                const text = row.innerText.toLowerCase();
                row.style.display = text.includes(searchValue) ? "" : "none";
            });
        }

        // Show first page on load
        showPage(currentPage);
    </script>
    <script>
        let customerData = {
                    <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        "<?php echo e($sub->sub_account_number); ?>": "<?php echo e($sub->phone); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $consignee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        "<?php echo e($con->id); ?>": "<?php echo e($con->phone); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                };
        let subAccountData = [];
        function fetchCustomerDetails(selectElement, nameFieldId, phoneFieldId) {
            let customerId = selectElement;
            if (customerId) {
                fetch(`/customer-details/${customerId}`)
                    .then(response => response.json())
                    .then(data => {
                        let nameSelect = document.getElementById(nameFieldId);
                        nameSelect.innerHTML = ""; // Clear existing options

                        if (data.error) {
                            console.error('Error:', data.error);
                            return;
                        }
                        // Populate dropdown with all names
                        data.customer_names.forEach(name => {
                            let option = document.createElement('option');
                            option.value = data.ids[name];
                            option.textContent = name;
                            nameSelect.appendChild(option);
                        });
                        subAccountData = data.sub;
                        // Set phone number
                        document.getElementById(phoneFieldId).value = data.phone || "";
                    })
                    .catch(error => console.error('Fetch error:', error));
            }
        }
        function selectReceiver(id, name, phone) {
                const receiverNameField = document.getElementById("receiver_name");
                const receiverNoField = document.getElementById("receiver_no");

                receiverNameField.innerHTML = `<option value="${id}" selected>${name}</option>`;

                fetchCustomerDetails(id, "receiver_name", "receiver_no");
                document.getElementById("receiverModal").classList.add("hidden");
            }

        function fetchNumber(selectElement, phoneFieldId) {
            let customerId = selectElement.value;
            let phoneField = document.getElementById(phoneFieldId);
            if (!phoneField) {
                console.error(`Element with ID ${phoneFieldId} not found.`);
                return;
            }
            // Check if the phone field is 'receiver_no' and use subAccount data
            if (phoneFieldId === 'receiver_no') {
                phoneField.value = customerId && subAccountData[customerId] ? subAccountData[customerId] : "N/A";
            } else {
                phoneField.value = customerId && customerData[customerId] ? customerData[customerId] : "N/A";
            }
        }
        // Attach event listeners after the page loads
        document.addEventListener("DOMContentLoaded", function() {
            //phone number for customer
            document.getElementById('customer_id').addEventListener('change', function() {
                fetchNumber(this, 'customer_no');
            });
            document.getElementById('receiver_name').addEventListener('change', function() {
                fetchNumber(this, 'receiver_no');
            });


            const openModalBtn = document.getElementById("openReceiverModal");
            const closeModalBtn = document.getElementById("closeReceiverModal");
            const modal = document.getElementById("receiverModal");

            openModalBtn.addEventListener("click", () => modal.classList.remove("hidden"));
            closeModalBtn.addEventListener("click", () => modal.classList.add("hidden"));

        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\SFX-1\resources\views\customer\info.blade.php ENDPATH**/ ?>