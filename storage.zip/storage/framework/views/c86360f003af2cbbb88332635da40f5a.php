<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <button onclick="window.history.back();" class="px-4 py-2 text-blue-600 rounded-md hover:text-blue-700 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600">
                    ←
                </button>
                <?php echo e(__('Statement of Account for: ') . (!empty($customer->first_name) || !empty($customer->last_name) ? $customer->first_name . ' ' . $customer->last_name : $customer->company_name)); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <?php if($groupedOrders->isEmpty()): ?>
            <div class="text-center py-4">
                <p class="text-gray-600 dark:text-gray-400">No orders found for this customer.</p>
            </div>
        <?php else: ?>
            <!-- Ship Tabs -->
            <div class="tabs">
                <ul class="flex border-b">
                    <?php $__currentLoopData = $groupedOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship => $voyageGroups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mr-1">
                            <a href="#tab-<?php echo e($ship); ?>" class="tab-link inline-block py-2 px-4 text-blue-500 hover:text-blue-800 rounded-t-md">M/V Everwin Star <?php echo e($ship); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!-- Ship Content -->
            <div class="tab-content">
                <?php $__currentLoopData = $groupedOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship => $voyageGroups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="tab-<?php echo e($ship); ?>" class="hidden">
                        <h3 class="text-lg font-semibold mt-8 mb-4 dark:text-gray-200">Ship: M/V Everwin Star <?php echo e($ship); ?></h3>
                        <div class="accordion">
                            <?php $__currentLoopData = $voyageGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voyage => $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $firstOrder = $orders->first();
                                    $origin = $firstOrder ? $firstOrder->origin : '';
                                    $destination = $firstOrder ? $firstOrder->destination : '';
                                ?>
                                <div class="accordion-item border-b">
                                    <button class="accordion-header w-full text-left py-2 px-4 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 dark:text-gray-200" onclick="toggleAccordion('voyage-<?php echo e($ship); ?>-<?php echo e($voyage); ?>')">
                                        Voyage: <?php echo e($voyage); ?> (<?php echo e($origin); ?> to <?php echo e($destination); ?>)
                                    </button>
                                    <div id="voyage-<?php echo e($ship); ?>-<?php echo e($voyage); ?>" class="accordion-content hidden">
                                        <div class="flex justify-between items-center py-2">
                                            <div class="flex space-x-2">
                                                <a href="<?php echo e(route('masterlist.soa_temp', [
                                                    'ship' => $ship, 
                                                    'voyage' => urlencode($voyage),
                                                    'customerId' => request('customer_id')
                                                ])); ?>" 
                                                class="px-3 py-1 text-white bg-green-500 rounded hover:bg-green-700"
                                                onclick="event.preventDefault(); openSOATemp('<?php echo e($ship); ?>', '<?php echo e(urlencode($voyage)); ?>', '<?php echo e(request('customer_id')); ?>')">
                                                    Print Statement of Account
                                                </a>
                                                
                                                <!-- Interest Calculation Button -->
                                                <button id="interest-btn-<?php echo e($ship); ?>-<?php echo e(Str::slug($voyage)); ?>"
                                                    class="px-3 py-1 text-white bg-red-500 rounded hover:bg-red-700"
                                                    onclick="activateInterest('<?php echo e($ship); ?>', '<?php echo e(urlencode($voyage)); ?>', '<?php echo e(request('customer_id')); ?>', '<?php echo e($ship); ?>-<?php echo e(Str::slug($voyage)); ?>')">
                                                    Activate 1% Interest
                                                </button>
                                                <div class="text-xs text-gray-600 italic mt-1">
                                                    Note: When the "Activate 1% Interest" button is clicked, the interest is NOT applied immediately. 1% interest only begins to apply after a 30-day grace period, and then it accrues at 1% per month.
                                                </div>
                                            </div>
                                            
                                            <!-- Interest Status Display -->
                                            <div id="interest-status-<?php echo e($ship); ?>-<?php echo e(Str::slug($voyage)); ?>" class="text-red-600 font-bold hidden">
                                                1% Interest Active - <span class="days-counter">0</span> days since activation
                                                <button id="deactivate-interest-btn-<?php echo e($ship); ?>-<?php echo e(Str::slug($voyage)); ?>"
                                                    class="ml-2 px-2 py-0.5 text-xs text-white bg-gray-500 rounded hover:bg-gray-700"
                                                    onclick="deactivateInterest('<?php echo e($ship); ?>', '<?php echo e(urlencode($voyage)); ?>', '<?php echo e(request('customer_id')); ?>', '<?php echo e($ship); ?>-<?php echo e(Str::slug($voyage)); ?>')">
                                                    Deactivate
                                                </button>
                                            </div>
                                        </div>
                                        <div class="overflow-x-auto mt-4">
                                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                                <thead class="bg-gray-100 dark:bg-gray-800">
                                                    <tr>
                                                        <th class="px-4 py-2">BL #</th>
                                                        <th class="px-4 py-2">Consignee</th>
                                                        <th class="px-4 py-2">Shipper</th>
                                                        <th class="px-4 py-2">Description</th>
                                                        <th class="px-4 py-2">Freight</th>
                                                        <th class="px-4 py-2">Valuation</th>
                                                        <th class="px-4 py-2">Padlock Fee</th>
                                                        <th class="px-4 py-2">Total Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                                    <?php 
                                                        $voyageTotal = 0;
                                                        $voyageFreight = 0;
                                                        $voyageValuation = 0;
                                                        $voyagePadlockFee = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                                            <td class="px-4 py-2 text-center"><?php echo e($order->orderId); ?></td>
                                                            <td class="px-4 py-2 text-center"><?php echo e($order->recName); ?></td>
                                                            <td class="px-4 py-2 text-center"><?php echo e($order->shipperName); ?></td>
                                                            <td class="px-4 py-2 text-center">
                                                                <?php $__currentLoopData = $order->parcels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parcel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <span><?php echo e($parcel->quantity); ?> <?php echo e($parcel->unit); ?> <?php echo e($parcel->itemName); ?> <?php echo e($parcel->desc); ?></span><br>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td class="px-4 py-2 text-right"><?php echo e(number_format($order->freight, 2)); ?></td>
                                                            <td class="px-4 py-2 text-right"><?php echo e(number_format($order->valuation, 2)); ?></td>
                                                            <td class="px-4 py-2 text-right">
                                                                <input style="width: 100px; border: none; outline: none; text-align:center;" 
                                                                    class="padlock-fee-input p-2 border rounded bg-white text-black dark:bg-gray-700 dark:text-white"
                                                                    data-order-id="<?php echo e($order->id); ?>"
                                                                    value="<?php echo e(number_format($order->padlock_fee ?? 0, 2)); ?>"
                                                                    placeholder="Enter Padlock Fee"/>
                                                            </td>
                                                            <td class="px-4 py-2 text-right"><?php echo e(number_format($order->totalAmount, 2)); ?></td>
                                                        </tr>
                                                        <?php $voyageTotal += $order->totalAmount;
                                                             $voyageFreight += $order->freight; 
                                                             $voyageValuation += $order->valuation;
                                                             $voyagePadlockFee += ($order->padlock_fee ?? 0);
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="bg-gray-50 dark:bg-gray-900 font-semibold">
                                                        <td colspan="4" class="px-4 py-2 text-right">Grand Total:</td>
                                                        <td class="px-4 py-2 text-right"><?php echo e(number_format($voyageFreight, 2)); ?></td>
                                                        <td class="px-4 py-2 text-right"><?php echo e(number_format($voyageValuation, 2)); ?></td>
                                                        <td class="px-4 py-2 text-right"><?php echo e(number_format($voyagePadlockFee ?? 0, 2)); ?></td>
                                                        <td class="px-4 py-2 text-right"><?php echo e(number_format($voyageTotal, 2)); ?></td>
                                                        <td></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <style>
        .tab-link.active {
            color: #1D4ED8;
            border-bottom: 2px solid #1D4ED8;
            background-color: #F3F4F6;
        }
        
        .dark .tab-link.active {
            color: #60A5FA;
            border-bottom: 2px solid #60A5FA;
            background-color: #374151;
        }

        .accordion-header {
            position: relative;
        }

        .accordion-header::after {
            content: '+';
            position: absolute;
            right: 1rem;
            transition: transform 0.2s ease-in-out;
        }

        .accordion-header.active::after {
            content: '-';
        }
    </style>

    <script>
        // Function to safely open the SOA temp page with special characters in voyage numbers
        function openSOATemp(ship, voyage, customerId) {
            // Create the URL with properly encoded parameters
            const baseUrl = "<?php echo e(url('/masterlist/soa_temp')); ?>";
            const url = `${baseUrl}/${ship}/${voyage}/${customerId}`;
            
            // Open in a new tab/window
            window.open(url, '_blank');
        }

        // Function to check for previously activated interest on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Find all interest buttons and check if they were previously activated
            document.querySelectorAll('[id^="interest-btn-"]').forEach(button => {
                const uniqueId = button.id.replace('interest-btn-', '');
                
                // Check if interest has been activated for this voyage
                const storageKey = `interest_start_${uniqueId}`;
                const startDate = localStorage.getItem(storageKey);
                
                if (startDate) {
                    // Interest was previously activated - hide button, show status
                    button.style.display = 'none';
                    
                    const statusElement = document.getElementById(`interest-status-${uniqueId}`);
                    if (statusElement) {
                        statusElement.classList.remove('hidden');
                        
                        // Update the day counter
                        updateDayCounter(uniqueId);
                        
                        // Set interval to update the counter every hour
                        setInterval(() => updateDayCounter(uniqueId), 3600000);
                    }
                }
            });
        });

        // Function to activate 1% interest calculation
        function activateInterest(ship, voyage, customerId, uniqueId) {
            if (!confirm('Are you sure you want to activate 1% interest calculation?')) {
                return;
            }

            // Save the current date to localStorage first (to ensure UI still works if backend fails)
            const now = new Date().toISOString();
            const storageKey = `interest_start_${uniqueId}`;
            localStorage.setItem(storageKey, now);
            
            // Update UI immediately
            document.getElementById(`interest-btn-${uniqueId}`).style.display = 'none';
            const statusElement = document.getElementById(`interest-status-${uniqueId}`);
            statusElement.classList.remove('hidden');
            updateDayCounter(uniqueId);
            setInterval(() => updateDayCounter(uniqueId), 3600000);

            // Create the URL for the interest activation endpoint
            const baseUrl = "<?php echo e(url('/masterlist/activate-interest')); ?>";
            const url = `${baseUrl}/${ship}/${voyage}/${customerId}`;
            
            console.log('Sending request to:', url);
            
            // Make the POST request to activate interest
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
            .then(response => {
                console.log('Response status:', response.status);
                if (!response.ok) {
                    throw new Error('Network response was not ok: ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                console.log('Response data:', data);
                if (data.success) {
                    // Update stored start date with the one from server (more accurate)
                    const storageKey = `interest_start_${uniqueId}`;
                    localStorage.setItem(storageKey, data.start_date);
                    
                    // Update the counter with the precise server date
                    updateDayCounter(uniqueId);
                    
                    // Show success message
                    alert('Interest calculation activated successfully!');
                } else {
                    alert('Error: ' + data.message);
                    // The UI is already updated so we don't need to revert anything
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('There was an issue communicating with the server, but interest calculation has been activated in the browser. The interest will be visible when you view the statement of account. Error: ' + error.message);
                // The UI is already updated, so we keep it functional despite the server error
            });
        }
        
        // Function to deactivate 1% interest calculation
        function deactivateInterest(ship, voyage, customerId, uniqueId) {
            if (!confirm('Are you sure you want to deactivate 1% interest calculation?')) {
                return;
            }
            
            // Create the URL for the interest deactivation endpoint
            const baseUrl = "<?php echo e(url('/masterlist/deactivate-interest')); ?>";
            const url = `${baseUrl}/${ship}/${voyage}/${customerId}`;
            
            console.log('Sending deactivation request to:', url);
            
            // Make the POST request to deactivate interest
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
            .then(response => {
                console.log('Response status:', response.status);
                if (!response.ok) {
                    throw new Error('Network response was not ok: ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                console.log('Response data:', data);
                if (data.success) {
                    // Remove the stored date
                    const storageKey = `interest_start_${uniqueId}`;
                    localStorage.removeItem(storageKey);
                    
                    // Update UI - show activate button, hide status
                    document.getElementById(`interest-btn-${uniqueId}`).style.display = 'inline-block';
                    document.getElementById(`interest-status-${uniqueId}`).classList.add('hidden');
                    
                    // Show success message
                    alert('Interest calculation deactivated successfully!');
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('There was an issue communicating with the server: ' + error.message);
            });
        }
        
        // Function to update the day counter
        function updateDayCounter(uniqueId) {
            const storageKey = `interest_start_${uniqueId}`;
            const startDateStr = localStorage.getItem(storageKey);
            
            console.log(`Updating counter for ${uniqueId}, start date: ${startDateStr}`);
            
            if (startDateStr) {
                const startDate = new Date(startDateStr);
                const currentDate = new Date();
                
                // Calculate days difference
                const diffTime = Math.abs(currentDate - startDate);
                const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
                
                console.log(`Days since activation: ${diffDays}`);
                
                // Update the counter display
                const counterElement = document.querySelector(`#interest-status-${uniqueId} .days-counter`);
                if (counterElement) {
                    counterElement.textContent = diffDays;
                    console.log(`Counter element updated for ${uniqueId}`);
                } else {
                    console.warn(`Counter element not found for ${uniqueId}`);
                }
                
                // Show the status display if it's hidden
                document.getElementById(`interest-status-${uniqueId}`).classList.remove('hidden');
                
                // Hide the activate button and show the deactivate button
                document.getElementById(`interest-btn-${uniqueId}`).style.display = 'none';
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            // Tab functionality
            const tabLinks = document.querySelectorAll('.tab-link');
            const tabContents = document.querySelectorAll('.tab-content > div');

            // Show first tab by default
            if (tabLinks.length > 0) {
                tabLinks[0].classList.add('active');
                tabContents[0].classList.remove('hidden');
            }

            tabLinks.forEach(tab => {
                tab.addEventListener('click', (e) => {
                    e.preventDefault();
                    
                    // Remove active class from all tabs and hide content
                    tabLinks.forEach(t => t.classList.remove('active'));
                    tabContents.forEach(c => c.classList.add('hidden'));
                    
                    // Add active class to clicked tab and show content
                    tab.classList.add('active');
                    const content = document.querySelector(tab.getAttribute('href'));
                    content.classList.remove('hidden');
                });
            });

            // Accordion functionality
            window.toggleAccordion = function(id) {
                const content = document.getElementById(id);
                const header = content.previousElementSibling;
                const isExpanded = !content.classList.contains('hidden');
                
                // Close all accordion items in the same ship tab
                const shipTab = content.closest('.tab-content > div');
                shipTab.querySelectorAll('.accordion-content').forEach(c => {
                    c.classList.add('hidden');
                    c.previousElementSibling.classList.remove('active');
                });
                
                // Toggle the clicked accordion item
                if (!isExpanded) {
                    content.classList.remove('hidden');
                    header.classList.add('active');
                }
            };
        });
    </script>

    <script>
        // Check for interest activations when the page loads
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Checking for previously activated interest');
            
            // Collect all interest buttons
            const interestButtons = document.querySelectorAll('[id^="interest-btn-"]');
            console.log(`Found ${interestButtons.length} interest buttons`);
            
            // Check each button for previous activation
            interestButtons.forEach(button => {
                const uniqueId = button.id.replace('interest-btn-', '');
                const storageKey = `interest_start_${uniqueId}`;
                const startDate = localStorage.getItem(storageKey);
                
                console.log(`Checking button ${uniqueId}: ${startDate ? 'Activated' : 'Not activated'}`);
                
                if (startDate) {
                    // Interest was previously activated
                    button.style.display = 'none';
                    
                    const statusElement = document.getElementById(`interest-status-${uniqueId}`);
                    if (statusElement) {
                        statusElement.classList.remove('hidden');
                        
                        // Update the day counter
                        updateDayCounter(uniqueId);
                        
                        // Set interval to update the counter every hour
                        setInterval(() => updateDayCounter(uniqueId), 3600000);
                    }
                }
            });
        });
    </script>

    <script>
        // For handling padlock fee inputs
        document.addEventListener('DOMContentLoaded', function () {
            const padlockFeeInputs = document.querySelectorAll('.padlock-fee-input');

            padlockFeeInputs.forEach(input => {
                input.addEventListener('input', function () {
                    const orderId = this.getAttribute('data-order-id');
                    const value = parseFloat(this.value) || 0;
                    
                    // Update the order field via AJAX
                    fetch(`/update-order-field/${orderId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({
                            field: 'padlock_fee',
                            value: value
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            console.log('Padlock fee updated successfully');
                            
                            // Update the total amount in the row
                            const row = this.closest('tr');
                            const totalCell = row.querySelector('td:last-child');
                            if (totalCell) {
                                totalCell.textContent = new Intl.NumberFormat('en-US', { 
                                    minimumFractionDigits: 2, 
                                    maximumFractionDigits: 2 
                                }).format(data.newTotal);
                            }
                        } else {
                            console.error('Failed to update padlock fee:', data.message);
                        }
                    })
                    .catch(error => console.error('Error:', error));
                });
            });
        });
    </script>

    <!-- Add a link to the Reset Interest page at the bottom of the SOA List page -->
    <div class="w-full text-center my-6" hidden>
        <a href="<?php echo e(route('masterlist.reset_interest')); ?>" class="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">
            Reset Interest Activation
        </a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\SFX-1\resources\views\masterlist\soa_list.blade.php ENDPATH**/ ?>