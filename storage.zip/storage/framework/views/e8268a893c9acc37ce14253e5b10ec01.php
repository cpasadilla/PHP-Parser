
<img src="/logo.png" style="width: 100%">


<?php /**PATH C:\xampp\htdocs\SFX-1\resources\views\components\application-logo.blade.php ENDPATH**/ ?>