<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <!-- Left Section (Back Button + Title) -->
            <h2 class="text-xl font-semibold leading-tight flex items-center">
                <button onclick="window.history.back();" class="px-4 py-2 text-blue-600 rounded-md hover:text-blue-700">←</button>
                <?php echo e(__('Order Page')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <div class="grid grid-cols-4 gap-4">
            <div>
                <form method="POST" action="<?php echo e(route('pushOrder')); ?>">
                    <?php echo csrf_field(); ?>
                    <!-- Shipper ID -->
                    <div class="space-y-2">
                        <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'shipper_id','value' => __('Shipper ID')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'shipper_id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Shipper ID'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                             <?php $__env->slot('icon', null, []); ?> 
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-hashtag'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['aria-hidden' => 'true','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                             <?php $__env->endSlot(); ?>
                            <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'shipper_id','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'shipper_id','value' => $data['customer_id'],'required' => true,'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Shipper ID')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'shipper_id','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'shipper_id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['customer_id']),'required' => true,'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Shipper ID')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                    </div>

                    <!-- Shipper Name -->
                    <div class="space-y-2">
                        <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'shipper_name','value' => __('Shipper Name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'shipper_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Shipper Name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                             <?php $__env->slot('icon', null, []); ?> 
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['aria-hidden' => 'true','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                             <?php $__env->endSlot(); ?>
                            <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'shipper_name','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'shipper_name','value' => $data['customer_name'],'required' => true,'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Shipper Name')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'shipper_name','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'shipper_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['customer_name']),'required' => true,'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Shipper Name')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                    </div>

                    <!-- Shipper Number -->
                    <div class="space-y-2">
                        <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'shipper_number','value' => __('Shipper Number')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'shipper_number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Shipper Number'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                             <?php $__env->slot('icon', null, []); ?> 
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-phone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['aria-hidden' => 'true','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                             <?php $__env->endSlot(); ?>
                            <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'shipper_number','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'shipper_number','value' => $data['customer_no'],'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Shipper Number')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'shipper_number','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'shipper_number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['customer_no']),'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Shipper Number')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                    </div>
            </div>

            <div>
                <!-- Consignee ID -->
                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'consignee_id','value' => __('Consignee ID')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'consignee_id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Consignee ID'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('icon', null, []); ?> 
                            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-hashtag'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['aria-hidden' => 'true','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                         <?php $__env->endSlot(); ?>
                        <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'consignee_id','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'consignee_id','value' => $data['receiver_id'],'required' => true,'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Consignee ID')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'consignee_id','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'consignee_id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['receiver_id']),'required' => true,'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Consignee ID')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                </div>

                <!-- Consignee Name -->
                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'consignee_name','value' => __('Consignee Name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'consignee_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Consignee Name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('icon', null, []); ?> 
                            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['aria-hidden' => 'true','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                         <?php $__env->endSlot(); ?>
                        <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'consignee_name','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'consignee_name','value' => $data['receiver_name'],'required' => true,'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Consignee Name')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'consignee_name','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'consignee_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['receiver_name']),'required' => true,'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Consignee Name')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                </div>

                <!-- Consignee Number -->
                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'consignee_number','value' => __('Consignee Number')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'consignee_number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Consignee Number'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('icon', null, []); ?> 
                            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-phone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['aria-hidden' => 'true','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                         <?php $__env->endSlot(); ?>
                        <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'consignee_number','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'consignee_number','value' => $data['receiver_no'],'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Consignee Number')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'consignee_number','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'consignee_number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['receiver_no']),'autofocus' => true,'readonly' => true,'placeholder' => ''.e(__('Consignee Number')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                </div>
            </div>

            <div>
                <!-- Origin -->
                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'origin','value' => __('Origin')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'origin','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Origin'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('icon', null, []); ?>  <?php $__env->endSlot(); ?>
                        <select id="origin" name="origin"
                            class="block w-full px-4 py-2 border rounded-md shadow-sm focus:ring focus:ring-indigo-300 dark:bg-gray-800 dark:text-white dark:border-gray-600"
                            required>
                            <option value="">Select Origin</option>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($location->location); ?>"><?php echo e($location->location); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                </div>

                <!-- Destination -->
                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'destination','value' => __('Destination')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'destination','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Destination'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('icon', null, []); ?>  <?php $__env->endSlot(); ?>
                        <select id="destination" name="destination"
                            class="block w-full px-4 py-2 border rounded-md shadow-sm focus:ring focus:ring-indigo-300 dark:bg-gray-800 dark:text-white dark:border-gray-600"
                            required>
                            <option value="">Select Destination</option>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location->location); ?>"><?php echo e($location->location); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                </div>

                <!-- Button for adding Location -->
                <?php if(Auth::user()->roles->roles == 'Admin'): ?>
                <button onclick="openLocationModal()" class="mt-4 px-4 py-2 text-white bg-blue-500 rounded-md hover:bg-blue-700">+ Add Location</button>
                <?php endif; ?>
            </div>

            <!-- Modal for adding Location -->
            <div id="locationModal" class="fixed inset-0 flex items-center justify-center hidden bg-black bg-opacity-50">
                <div class="bg-white dark:bg-[#222738] rounded-lg shadow-lg p-6 w-1/3">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-200 mb-4">Add New Location</h2>

                    <label for="newLocation" class="block font-medium text-gray-900 dark:text-gray-200">Location Name:</label>
                    <input type="text" id="newLocation" class="w-full p-2 border rounded-md text-gray-900 dark:text-white bg-gray-100 dark:bg-gray-700 mb-4 focus:ring focus:ring-indigo-300">

                    <div class="flex justify-end">
                        <button onclick="closeLocationModal()" class="px-3 py-1 bg-gray-500 text-white dark:text-white rounded-md hover:bg-gray-700">Cancel</button>
                        <button onclick="addLocation()" class="px-3 py-1 ml-2 bg-blue-500 text-white dark:text-white rounded-md hover:bg-blue-700">Add</button>
                    </div>
                </div>
            </div>

            <div>
                <!-- Ship Number -->
                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'ship_no','value' => __('Ship Number')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'ship_no','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Ship Number'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('icon', null, []); ?>  <?php $__env->endSlot(); ?>
                        <select id="ship_no" name="ship_no"
                            class="block w-full p-2 border rounded-md shadow-sm focus:ring focus:ring-indigo-300 dark:bg-gray-800 dark:text-white dark:border-gray-600">
                            <?php $__currentLoopData = $ships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($ship->status == 'DRYDOCKED'): ?>

                                <?php else: ?>
                                    <option value=<?php echo e($ship->ship_number); ?> ><?php echo e($ship->ship_number); ?></option>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                </div>

                <!-- Voyage Number -->
                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'voyage_no','value' => __('Voyage Number')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'voyage_no','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Voyage Number'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                    <div class="flex items-center gap-2"> <!-- Flex container for input and buttons -->
                        <!-- Input Field -->
                        <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => ['class' => 'flex-1 relative']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'flex-1 relative']); ?>
                             <?php $__env->slot('icon', null, []); ?> 
                                <i class="fas fa-anchor absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                             <?php $__env->endSlot(); ?>
                            <input id="voyage_no" name="voyage_no"
                                class="block w-full pl-10 p-2 border rounded-md shadow-sm focus:ring focus:ring-indigo-300 dark:bg-gray-800 dark:text-white dark:border-gray-600"
                                type="text" required autofocus
                                placeholder="<?php echo e(__('Voyage Number')); ?>"
                            />
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>

                        <!-- Buttons (Only for Ship I or II) -->
                        <div id="voyageButtons" class="flex gap-2"> <!-- Buttons container -->
                            <button type="button" onclick="setVoyageSuffix('IN')" class="px-3 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 text-sm">IN</button>
                            <button type="button" onclick="setVoyageSuffix('OUT')" class="px-3 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 text-sm">OUT</button>
                        </div>
                    </div>
                </div>

                <!-- Container Number -->
                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'container_no','value' => __('Container Number')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'container_no','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Container Number'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('icon', null, []); ?> 
                            <i class="fas fa-box w-5 h-5"></i>
                         <?php $__env->endSlot(); ?>
                        <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'container_no','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'container_no','value' => old('container_no'),'placeholder' => ''.e(__('Container Number')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'container_no','class' => 'block w-full focus:ring focus:ring-indigo-300','type' => 'text','name' => 'container_no','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('container_no')),'placeholder' => ''.e(__('Container Number')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
                </div>
            </div>
        </div><br>

        <div class="row justify-content-center">
            <div class="col-lg-12 col-12  min-vh-500">
                <div class="box">
                    <div class="col-sm-12 text-center">
                        <img src="<?php echo e(asset('images/line_5.png')); ?>" class="mx-auto w-full mt-2">
                    </div>
                </div>
            </div>
        </div><br>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <!-- Cargo Status -->
            <div class="space-y-2">
                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'cargo_status','value' => __('Cargo Status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'cargo_status','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Cargo Status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('icon', null, []); ?>  <?php $__env->endSlot(); ?>
                    <select id="cargo_status" name="cargo_status"
                        class="block w-full p-2 h-10 border rounded-md shadow-sm focus:ring focus:ring-indigo-300 dark:bg-gray-800 dark:text-white dark:border-gray-600">
                        <option value="CHARTERED" <?php echo e($data['customer_no'] == 'CHARTERED' ? 'selected' : ''); ?>>CHARTERED</option>
                        <option value="LOOSE CARGO" <?php echo e($data['customer_no'] == 'LOOSE CARGO' ? 'selected' : ''); ?>>LOOSE CARGO</option>
                        <option value="STUFFING" <?php echo e($data['customer_no'] == 'STUFFING' ? 'selected' : ''); ?>>STUFFING</option>
                    </select>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
            </div>

            <!-- Gate Pass Number -->
            <div class="space-y-2">
                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'gatepass','value' => __('Gate Pass Number')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'gatepass','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Gate Pass Number'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('icon', null, []); ?> 
                        <i class="fas fa-ticket-alt w-5 h-5"></i>
                     <?php $__env->endSlot(); ?>
                    <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'gatepass','class' => 'block w-full h-10 focus:ring focus:ring-indigo-300','type' => 'text','name' => 'gatepass','value' => old('gatepass'),'placeholder' => ''.e(__('Gate Pass Number')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'gatepass','class' => 'block w-full h-10 focus:ring focus:ring-indigo-300','type' => 'text','name' => 'gatepass','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('gatepass')),'placeholder' => ''.e(__('Gate Pass Number')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
            </div>

            <!-- Checker Name -->
            <div class="space-y-2">
                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'checker','value' => __('Checker Name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'checker','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Checker Name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => ['class' => 'flex-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'flex-1']); ?>
                     <?php $__env->slot('icon', null, []); ?>  <?php $__env->endSlot(); ?>
                    <select id="checker" name="checker"
                        class="block w-full p-2 h-10 border rounded-md shadow-sm focus:ring focus:ring-indigo-300 dark:bg-gray-800 dark:text-white dark:border-gray-600">
                        <option value="">Select Checker</option>
                    </select>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
            </div>
            <!-- Buttons (Only for Admin) -->
            <?php if(Auth::user()->roles->roles == 'Admin'): ?>
                <div class="flex gap-2"> <!-- Buttons container -->
                    <button type="button" id="addChecker" class="w-24 py-1 h-10 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm">Add</button>
                    <button type="button" id="deleteChecker" class="w-24 py-1 h-10 bg-red-600 text-white rounded-md hover:bg-red-700 text-sm">Delete</button>
                </div>
            <?php endif; ?>

            <!-- Remark -->
            <div class="space-y-2">
                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'remark','value' => __('Remark')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'remark','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Remark'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('icon', null, []); ?> 
                        <i class="fas fa-book w-5 h-5"></i>
                     <?php $__env->endSlot(); ?>
                    <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'remark','class' => 'block w-full h-10 focus:ring focus:ring-indigo-300','type' => 'text','name' => 'remark','value' => old('remark'),'placeholder' => ''.e(__('Remark')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'remark','class' => 'block w-full h-10 focus:ring focus:ring-indigo-300','type' => 'text','name' => 'remark','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('remark')),'placeholder' => ''.e(__('Remark')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
            </div>

            <!-- Value -->
            <div class="space-y-2">
                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'valuation','value' => __('Value')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'valuation','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Value'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('icon', null, []); ?> 
                        <i class="fas fa-dollar w-5 h-5"></i>
                     <?php $__env->endSlot(); ?>
                    <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'valuation','class' => 'block w-full h-10 focus:ring focus:ring-indigo-300','type' => 'text','name' => 'valuation','value' => old('valuation'),'autofocus' => true,'placeholder' => ''.e(__('Value')).'','oninput' => 'formatNumberInput(this)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'valuation','class' => 'block w-full h-10 focus:ring focus:ring-indigo-300','type' => 'text','name' => 'valuation','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('valuation')),'autofocus' => true,'placeholder' => ''.e(__('Value')).'','oninput' => 'formatNumberInput(this)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
            </div>

            <!-- Other Charges -->
            <div class="space-y-2">
                <?php if (isset($component)) { $__componentOriginal306f477fe089d4f950325a3d0a498c1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal306f477fe089d4f950325a3d0a498c1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.label','data' => ['for' => 'other','value' => __('Other Charges')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'other','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Other Charges'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $attributes = $__attributesOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__attributesOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal306f477fe089d4f950325a3d0a498c1c)): ?>
<?php $component = $__componentOriginal306f477fe089d4f950325a3d0a498c1c; ?>
<?php unset($__componentOriginal306f477fe089d4f950325a3d0a498c1c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald599939fa78ef9d91bfef4309fb3a81c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-with-icon-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-with-icon-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('icon', null, []); ?> 
                        <i class="fas fa-dollar w-5 h-5"></i>
                     <?php $__env->endSlot(); ?>
                    <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['withicon' => true,'id' => 'other','class' => 'block w-full h-10 focus:ring focus:ring-indigo-300','type' => 'text','name' => 'other','value' => old('other'),'autofocus' => true,'placeholder' => ''.e(__('Other Charges')).'','oninput' => 'formatNumberInput(this)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withicon' => true,'id' => 'other','class' => 'block w-full h-10 focus:ring focus:ring-indigo-300','type' => 'text','name' => 'other','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('other')),'autofocus' => true,'placeholder' => ''.e(__('Other Charges')).'','oninput' => 'formatNumberInput(this)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $attributes = $__attributesOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__attributesOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c)): ?>
<?php $component = $__componentOriginald599939fa78ef9d91bfef4309fb3a81c; ?>
<?php unset($__componentOriginald599939fa78ef9d91bfef4309fb3a81c); ?>
<?php endif; ?>
            </div>
        </div>
    </div><br>

    <input type="hidden" id="cartData" name="cartData">
    <input type="hidden" id="cartTotal" name="cartTotal">

    <div class="p-6 bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <div class="card-header flex justify-between items-center">
            <h5 class="font-semibold flex items-center">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-shopping-cart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?> Cart
            </h5>

            <span onclick="openModal()" class="px-4 py-2 text-white bg-blue-500 rounded-md hover:bg-blue-700">Open Listing</span>
        </div>
        <br>
        <table class="w-full border-collapse">
            <thead class="bg-gray-200 dark:bg-dark-eval-0">
                <tr>
                    <th class="p-2 text-black-700 dark:text-white-700">Quantity</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Item Name</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Category</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Description</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Unit</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Measurements (L X W H )</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Multiplier</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Rate</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Total</th>
                    <th class="p-2 text-black-700 dark:text-white-700">Edit</th>
                    <th class="p-2 text-center text-black-700 dark:text-white-700">Delete</th>
                </tr>
            </thead>
            <tbody id="cartTableBody">
                <!-- Items will be added here dynamically -->
            </tbody>
        </table>
        <br>
        <h6 class="font-semibold text-black-700 dark:text-white-700">
            Total Price: <span id="totalItems">0</span>
        </h6>
        <div class="flex justify-end mt-3">
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'justify-center w-full gap-2','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'justify-center w-full gap-2','type' => 'submit']); ?>
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-shopping-cart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                <span><?php echo e(__('Submit Order')); ?></span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
        </div>
    </div><br>
                </form>

    <!-- Modal -->
    <div id="addToCartModal" class="fixed inset-0 flex items-center justify-center hidden bg-black bg-opacity-50">
        <div class="bg-white dark:bg-[#222738] rounded-lg shadow-lg p-4 w-1/2 max-w-5xl max-h-[80vh] overflow-auto">
            <!-- Top Row: Listing and Search Bar -->
            <div class="flex justify-between items-center mb-2">
                <!-- Left Side: Listing -->
                <h5 class="font-semibold text-lg">Listing</h5>

                <!-- Right Side: Search Bar with Button -->
                <div class="flex items-center space-x-2">
                    <input type="text" id="searchInput" placeholder="Search items..."
                    class="w-full p-2 border rounded-md bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">
                </div>
            </div>

            <div class="flex gap-4">
                <!-- Left Column: Input Fields -->
                <div class="w-1/2">
                    <label class="block font-medium text-gray-900 dark:text-gray-200">Item Code:</label>
                    <input type="text" id="itemCode" name="itemCode" readonly
                        class="w-full p-2 border rounded-md mb-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">

                    <label class="block font-medium text-gray-900 dark:text-gray-200">Item Name:</label>
                    <input type="text" id="itemName" name="itemName" readonly
                        class="w-full p-2 border rounded-md mb-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">

                    <label class="block font-medium text-gray-900 dark:text-gray-200">Unit:</label>
                    <div class="flex items-center gap-2">
                        <select id="unit" name="unit"
                            class="w-full p-2 border rounded-md bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">
                            <option value="">Select Unit</option>
                            <option value="PCS">PCS</option>
                            <option value="PC">PC</option>
                            <option value="BOX">BOX</option>
                            <option value="BOXS">BOXS</option>
                            <option value="CASE">CASE</option>
                            <option value="BUNDLE">BUNDLE</option>
                            <option value="CRATE">CRATE</option>
                            <option value="PAIL">PAIL</option>
                            <option value="PLASTIC">PLASTIC</option>
                            <option value="UNIT">UNIT</option>
                            <option value="BAG">BAG</option>
                            <option value="BAGS">BAGS</option>
                            <option value="ROLL">ROLL</option>
                            <option value="SACK">SACK</option>
                            <option value="SACKS">SACKS</option>
                            <option value="BALE">BALE</option>
                            <option value="BALES">BALES</option>
                            <option value="CBM">CBM</option>
                            <option value="TIN">TIN</option>
                            <option value="TINS">TINS</option>
                            <option value="SET">SET</option>
                            <option value="SETS">SETS</option>
                            <option value="CTN">CTN</option>
                            <option value="CYL">CYL</option>
                            <option value="KG">KG</option>
                            <option value="RIMS">RIMS</option>
                        </select>
                        <button type="button" id="addUnit"
                            class="px-3 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                            Add
                        </button>
                    </div>

                    <label class="block font-medium text-gray-900 dark:text-gray-200">Category:</label>
                    <input type="text" id="category" name="category" readonly
                        class="w-full p-2 border rounded-md mb-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">
                    <label class="block font-medium text-gray-900 dark:text-gray-200">Weight:</label>
                    <input type="text" id="weight" name="weight"
                        class="w-full p-2 border rounded-md mb-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">
                    <!-- Measurements -->
                    <div class="space-y-2" id="measurements">
                        <label class="block font-medium text-gray-900 dark:text-gray-200">Measurements (L × W × H):</label>
                        <div class="grid grid-cols-4 gap-2 items-center">
                            <input type="number" id="length" name="length"
                                class="p-2 border rounded-md bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200"
                                placeholder="Length" min="0" step="0.01">

                            <input type="number" id="width" name="width"
                                class="p-2 border rounded-md bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200"
                                placeholder="Width" min="0" step="0.01">

                            <input type="number" id="height" name="height"
                                class="p-2 border rounded-md bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200"
                                placeholder="Height" min="0" step="0.01">

                            <input list="multipliers" id="multiplier" name="multiplier" type="number"
                                class="p-2 border rounded-md bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200"
                                placeholder="Multiplier" min="0" step="0.01">
                        </div>
                    </div>
                    <div class="fix" id="fixed" >
                        <label class="block font-medium text-gray-900 dark:text-gray-200">Price:</label>
                        <input type="text" id="price" name="price" readonly
                            class="w-full p-2 border rounded-md mb-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">
                    </div>
                    <label class="block font-medium text-gray-900 dark:text-gray-200">Quantity:</label>
                    <input type="text" id="quantity" name="quantity"
                        class="w-full p-2 border rounded-md mb-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">

                    <label class="block font-medium text-gray-900 dark:text-gray-200">Description:</label>
                    <textarea id="description" name="description"
                        class="w-full p-2 border rounded-md mb-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white h-20 focus:ring focus:ring-indigo-200">
                    </textarea>
                </div>

                <!-- Right Column: Table -->
                <div class="w-2/3">
                    <div id="tableContainer"
                        class="border border-gray-300 dark:border-gray-600 resize-y overflow-auto p-2"
                        style="min-height: 100px; max-height: 600px; height: 1100px;">
                        <table class="w-full border-collapse border border-gray-300 dark:border-gray-600 text-sm">
                            <thead class="bg-gray-200 dark:bg-dark-eval-0">
                                <tr>
                                    <th class="p-3 border">Item Code</th>
                                    <th class="p-3 border">Item Name</th>
                                    <th class="p-3 border ">Category
                                        <select id="categoryFilter"
                                            class="w-full p-2 border rounded-md font-small bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white focus:ring focus:ring-indigo-200">
                                            <option value="">Show All</option>
                                            <?php $__currentLoopData = $lists->pluck('category')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category); ?>"><?php echo e($category); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="itemTableBody">
                                <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="item-row" data-category="<?php echo e($list->category); ?>">
                                    <td class="p-3 border"><?php echo e($list->item_code); ?></td>
                                    <td class="p-3 border"><?php echo e($list->item_name); ?></td>
                                    <td class="p-3 border"><?php echo e($list->category); ?></td>
                                    <td class="p-3 border" hidden><?php echo e(number_format($list->price, 2)); ?></td>
                                    <td class="p-3 border" hidden><?php echo e($list->multiplier); ?></td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <button onclick="clearFields()" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">Clear Fields</button>

            <!-- Bottom Right Buttons -->
            <div class="flex justify-end mt-3">
                <button onclick="closeModal()" class="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-700 dark:bg-gray-600 dark:hover:bg-gray-500">Cancel</button>
                <button id="addToCart" onclick="addToCart()" class="px-4 py-2 ml-2 bg-emerald-500 text-white rounded-md hover:bg-emerald-700 dark:bg-emerald-500 dark:hover:bg-emerald-700 flex items-center space-x-2">
                    <i class="fas fa-shopping-cart"></i>
                    <span> Add to Cart</span>
                </button>
                <button id="saveButton" onclick="saveUpdatedItem()" class="px-4 py-2 ml-2 bg-emerald-500 text-white rounded-md hover:bg-emerald-700 dark:bg-emerald-500 dark:hover:bg-emerald-700 flex items-center space-x-2 hidden">
                    <i class="fas fa-floppy-disk"></i>
                    <span>Update</span>
                </button>
            </div>
        </div>
    </div>

    <!--td class="p-2 text-center">${item.description} - Weight ${item.weight}</td-->
    <script>
        let cart = [];
        let totalPrice = 0;
        let edit = 0;

        function openModal() {
            document.getElementById('addToCartModal').classList.remove('hidden');
        }

        function closeModal() {
            document.getElementById('addToCart').classList.remove('hidden'); // Show Add to Cart
            document.getElementById('saveButton').classList.add('hidden'); // Hide Save Button
            document.getElementById('addToCartModal').classList.add('hidden');
        }

        function addToCart() {
            let l = parseFloat(document.getElementById('length').value) || 1;
            let w = parseFloat(document.getElementById('width').value) || 1;
            let h = parseFloat(document.getElementById('height').value) || 1;
            let m = parseFloat(document.getElementById('multiplier').value) || 'N/A';
            let price = parseFloat(document.getElementById('price').value); // Ensure price is a number
            let quantity = parseFloat(document.getElementById('quantity').value) || 1;
            let total = 0;

            if (m == 'N/A' || m == '' || m == 0) {
                total = price * quantity;
            } else {
                price = l * w * h * m;
                total = price * quantity;
            }

            totalPrice += total;
            const item = {
                itemCode: document.getElementById('itemCode').value,
                itemName: document.getElementById('itemName').value,
                unit: document.getElementById('unit').value,
                category: document.getElementById('category').value,
                weight: document.getElementById('weight').value,
                length: l,
                width: w,
                height: h,
                multiplier: m,
                price: price,
                description: document.getElementById('description').value,
                quantity: quantity,
                total: total
            };

            cart.push(item);
            updateCartTable();
            clearFields(); // Clear all fields after adding to cart
            closeModal();
        }

        function formatPrice(value) {
            return new Intl.NumberFormat('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(value);
        }

        function updateCartTable() {
            const cartTableBody = document.getElementById('cartTableBody');
            cartTableBody.innerHTML = '';

            const cartDataInput = document.getElementById('cartData');
            cartDataInput.value = JSON.stringify(cart);

            document.getElementById('totalItems').textContent = formatPrice(totalPrice);
            document.getElementById('cartTotal').value = formatPrice(totalPrice);


            cart.forEach((item, index) => {
                const row = document.createElement('tr');
                row.className = "border-b";

                row.innerHTML = `
                    <td class="p-2 text-center">${item.quantity}</td>
                    <td class="p-2 text-center">${item.itemName}</td>
                    <td class="p-2 text-center">${item.category}</td>
                    <td class="p-2 text-center">${item.description} - Weight ${item.weight}</td>
                    <td class="p-2 text-center">${item.unit}</td>
                    `
                    if (item.multiplier == 'N/A') {
                        row.innerHTML += `
                        <td class="p-2 text-center">N/A</td>
                        `
                    }
                    else{
                        row.innerHTML += `
                        <td class="p-2 text-center">${item.length} × ${item.width} × ${item.height}</td>
                        `
                    }

                    row.innerHTML += `
                    <td class="p-2 text-center">${Number(item.multiplier).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td class="p-2 text-center">${Number(item.price).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td class="p-2 text-center">${Number(item.total).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td class="p-2 text-center">
                        <a href="#" class="text-blue-500 text-center" onclick="openEditModal(${index})">
                            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'warning','class' => 'items-center max-w-xs gap-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'warning','class' => 'items-center max-w-xs gap-2']); ?>
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-pencil'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                        </a>
                    </td>
                    <td class="p-2 text-center">
                        <a href="#" class="text-blue-500 text-center" onclick="deleteItem(${index})">
                            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'danger','class' => 'items-center max-w-xs gap-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'danger','class' => 'items-center max-w-xs gap-2']); ?>
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-trash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                        </a>
                    </td>
                `;
                cartTableBody.appendChild(row);
            });
            toggleButtonsVisibility();
        }

        function deleteItem(index) {
            totalPrice -= cart[index].total;
            document.getElementById('totalItems').textContent = formatPrice(totalPrice);
            cart.splice(index, 1);
            updateCartTable();
        }

        function toggleButtonsVisibility() {
            const editButtons = document.querySelectorAll("[variant='warning']");
            const deleteButtons = document.querySelectorAll("[variant='danger']");

            const visibility = cart.length > 0 ? "" : "hidden";

            editButtons.forEach(btn => btn.style.visibility = visibility);
            deleteButtons.forEach(btn => btn.style.visibility = visibility);
        }

        function openEditModal(index) {
            document.getElementById('addToCart').classList.add('hidden'); // Hide Add to Cart
            document.getElementById('saveButton').classList.remove('hidden'); // Show Save Button

            const item = cart[index];

            document.getElementById('itemCode').value = item.itemCode;
            document.getElementById('itemName').value = item.itemName;
            document.getElementById('unit').value = item.unit;
            document.getElementById('category').value = item.category;
            document.getElementById('weight').value = item.weight;
            document.getElementById('length').value = item.length;
            document.getElementById('width').value = item.width;
            document.getElementById('height').value = item.height;
            document.getElementById('multiplier').value = item.multiplier;
            document.getElementById('price').value = item.price;
            document.getElementById('description').value = item.description;
            document.getElementById('quantity').value = item.quantity;
            edit = item.total;
            // Store the index for updating later
            document.getElementById('saveButton').setAttribute('data-index', index);

            // Show the modal
            document.getElementById('addToCartModal').classList.remove('hidden');
        }

        // Function to save the updated data
        function saveUpdatedItem() {
            document.getElementById('addToCart').classList.remove('hidden'); // Show Add to Cart
            document.getElementById('saveButton').classList.add('hidden'); // Hide Save Button
            const currentEditIndex = document.getElementById('saveButton').getAttribute('data-index'); // Get stored index

            if (currentEditIndex !== null) {
                let l = parseFloat(document.getElementById('length').value) || 1;
                let w = parseFloat(document.getElementById('width').value) || 1;
                let h = parseFloat(document.getElementById('height').value) || 1;
                let m = parseFloat(document.getElementById('multiplier').value) || 'N/A';
                let price = parseFloat(document.getElementById('price').value); // Ensure price is a number
                let quantity = parseFloat(document.getElementById('quantity').value) || 1;
                let total = 0;
                if (m == 'N/A' || m == '' || m == 0) {
                total = price * quantity;
                }
                else if (m !=  '' || m != '' || m != 0){
                    price = l * w * h * m;
                    total = price * quantity;
                }
                else {
                }
                totalPrice -= edit;
                totalPrice += total;
                document.getElementById('totalItems').textContent = formatPrice(totalPrice);

                cart[currentEditIndex] = {
                    itemCode: document.getElementById('itemCode').value,
                    itemName: document.getElementById('itemName').value,
                    unit: document.getElementById('unit').value,
                    category: document.getElementById('category').value,
                    weight: document.getElementById('weight').value,
                    length: l,
                    width: w,
                    height: h,
                    multiplier: m,
                    price: price,
                    description: document.getElementById('description').value,
                    quantity: quantity,
                    total: total
                };

                // Update the displayed table with new data
                updateCartTable();
                closeModal();
            }
        }

        // Populate form fields on row click
        document.addEventListener('DOMContentLoaded', () => {
            const tableBody = document.getElementById('itemTableBody');

            tableBody.addEventListener('click', (event) => {
                const row = event.target.closest('tr');
                if (!row) return;

                // Extract data from the clicked row
                const cells = row.getElementsByTagName('td');
                const itemCode = cells[0].textContent.trim();
                const itemName = cells[1].textContent.trim();
                const category = cells[2].textContent.trim();
                const price = cells[3].textContent.trim();
                const multiplier = cells[4].textContent.trim();

                // Populate the input fields
                document.getElementById('itemCode').value = itemCode;
                document.getElementById('itemName').value = itemName;
                document.getElementById('category').value = category;
                document.getElementById('price').value = price;
                document.getElementById('multiplier').value = multiplier;

            });
        });

        // Search function
        document.addEventListener('DOMContentLoaded', () => {
            const searchInput = document.getElementById('searchInput');
            const rows = document.querySelectorAll('#itemTableBody .item-row');
            searchInput.addEventListener('keyup', () => {
                const query = searchInput.value.toLowerCase();

                rows.forEach(row => {
                    const itemCode = row.children[0].textContent.toLowerCase();
                    const itemName = row.children[1].textContent.toLowerCase();
                    const category = row.children[2].textContent.toLowerCase();

                    // Check if search matches any column
                    if (itemCode.includes(query) || itemName.includes(query) || category.includes(query)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            // Populate form on row click
            document.getElementById('itemTableBody').addEventListener('click', (event) => {
                const row = event.target.closest('tr');
                if (!row) return;

                document.getElementById('itemCode').value = row.children[0].textContent.trim();
                document.getElementById('itemName').value = row.children[1].textContent.trim();
                document.getElementById('category').value = row.children[2].textContent.trim();
                document.getElementById('price').value = row.children[3].textContent.trim();
            });
        });

        // JavaScript for Filtering
        document.getElementById("categoryFilter").addEventListener("change", function() {
            let selectedCategory = this.value.toLowerCase();
            document.querySelectorAll("#itemTableBody .item-row").forEach(row => {
                let rowCategory = row.getAttribute("data-category").toLowerCase();
                if (selectedCategory === "" || rowCategory === selectedCategory) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const shipNoSelect = document.getElementById('ship_no');
            const voyageNoInput = document.getElementById('voyage_no');
            const voyageButtons = document.getElementById('voyageButtons');

            shipNoSelect.addEventListener('change', function () {
                const selectedShip = shipNoSelect.value;

                if (selectedShip === 'I' || selectedShip === 'II') {
                    // Show buttons for IN and OUT
                    voyageButtons.classList.remove('hidden');


                } else {
                    // Hide buttons for other ships
                    voyageButtons.classList.add('hidden');

                    // Remove the suffix logic
                    voyageNoInput.removeEventListener('input', () => {});
                }
            });

            // Function to set the voyage suffix
            window.setVoyageSuffix = function (suffix) {
                const voyageValue = voyageNoInput.value.trim().replace(/ - (IN|OUT)$/, '');
                voyageNoInput.value = voyageValue + ' - ' + suffix;
            };
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const checkerSelect = document.getElementById("checker");
            const addCheckerBtn = document.getElementById("addChecker");
            const deleteCheckerBtn = document.getElementById("deleteChecker");

            // Checker options based on origin
            const checkerOptions = {
                "MANILA": ["", "ALDAY", "ANCHETA", "BERNADOS", "CACHO", "ESGUERRA", "MORENO", "VICTORIANO", "YUMUL", "ZERRUDO"],
                "BATANES": ["", "SOL", "TIRSO", "VARGAS", "NICK", "JOSIE", "JEN"]
            };

            function populateCheckerOptions(origin) {
                checkerSelect.innerHTML = ""; // Clear existing options
                let options = checkerOptions[origin] || [];
                options.forEach(option => {
                    let opt = document.createElement("option");
                    opt.value = option;
                    opt.textContent = option;
                    checkerSelect.appendChild(opt);
                });
            }

            function updateCheckerOptions() {
                let origin = document.getElementById("origin")?.value?.toUpperCase();
                if (origin && checkerOptions[origin]) {
                    populateCheckerOptions(origin);
                }
            }

            // Update options when origin changes
            document.getElementById("origin")?.addEventListener("change", updateCheckerOptions);

            // Load default options on page load
            updateCheckerOptions();
        });
    </script>

    <script>
        function formatNumberInput(input) {
            // Remove non-numeric characters except the decimal point
            let value = input.value.replace(/,/g, '');
            if (!isNaN(value) && value !== '') {
                let parts = value.split('.');
                parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ","); // Add commas for thousands
                input.value = parts.join('.'); // Rejoin integer and decimal parts
            }
        }

        // Ensure raw value is submitted without commas
        document.querySelector('form').addEventListener('submit', function() {
            document.getElementById('valuation').value = document.getElementById('valuation').value.replace(/,/g, '');
            document.getElementById('other').value = document.getElementById('other').value.replace(/,/g, '');
        });
    </script>

    <script>
        // For add new Unit button
        document.getElementById('addUnit').addEventListener('click', function () {
            let unitSelect = document.getElementById('unit');
            let newUnit = prompt("Enter new unit:");

            if (newUnit) {
                newUnit = newUnit.toUpperCase();

                // Add to local storage
                let storedUnits = JSON.parse(localStorage.getItem("customUnits")) || [];
                if (!storedUnits.includes(newUnit)) {
                    storedUnits.push(newUnit);
                    localStorage.setItem("customUnits", JSON.stringify(storedUnits));
                }

                // Add to dropdown
                let option = document.createElement('option');
                option.value = newUnit;
                option.text = newUnit;
                unitSelect.appendChild(option);
                unitSelect.value = newUnit;
            }
        });

        // Load saved units from local storage on page load
        document.addEventListener("DOMContentLoaded", function () {
            let unitSelect = document.getElementById('unit');
            let storedUnits = JSON.parse(localStorage.getItem("customUnits")) || [];

            storedUnits.forEach(unit => {
                let option = document.createElement('option');
                option.value = unit;
                option.text = unit;
                unitSelect.appendChild(option);
            });
        });

        // Function to Clear All Input Fields
        function clearFields() {
            document.getElementById('itemCode').value = "";
            document.getElementById('itemName').value = "";
            document.getElementById('unit').value = "";
            document.getElementById('category').value = "";
            document.getElementById('weight').value = "";
            document.getElementById('length').value = "";
            document.getElementById('width').value = "";
            document.getElementById('height').value = "";
            document.getElementById('multiplier').value = "";
            document.getElementById('price').value = "";
            document.getElementById('quantity').value = "";
            document.getElementById('description').value = "";
        }
    </script>

    <!-- LOCATION FUNCTION -->
    <?php if(Auth::user()->roles->roles == 'Admin'): ?>
        <script>
            function openLocationModal() {
                let modal = document.getElementById("locationModal");
                modal.classList.add("show");
                modal.classList.remove("hidden");

                // Disable inputs outside modal
                document.querySelectorAll("input, select, button").forEach(el => {
                    if (!modal.contains(el)) {
                        el.disabled = true;
                    }
                });
            }

            function closeLocationModal() {
                let modal = document.getElementById("locationModal");
                modal.classList.remove("show");
                modal.classList.add("hidden");

                // Enable inputs outside modal
                document.querySelectorAll("input, select, button").forEach(el => {
                    if (!modal.contains(el)) {
                        el.disabled = false;
                    }
                });
            }

            // Function to add location via AJAX request
            function addLocation() {
                const locationInput = document.getElementById("newLocation").value.trim();

                if (locationInput) {
                    // Send location to backend
                    fetch('/add-location/' + encodeURIComponent(locationInput), {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        },
                    })
                    .then(response => response.json())
                    .then(data => {
                        // Update dropdowns with new data
                        updateDropdowns(data);

                        // Clear input and close modal
                        document.getElementById("newLocation").value = "";
                        closeLocationModal();
                    })
                    .catch(error => console.error('Error:', error));
                }
            }

            // Helper function to update Origin and Destination dropdowns
            function updateDropdowns(locations) {
                const originSelect = document.getElementById("origin");
                const destinationSelect = document.getElementById("destination");

                // Clear existing options
                originSelect.innerHTML = "";
                destinationSelect.innerHTML = "";

                // Add updated locations to dropdowns
                locations.forEach(location => {
                    let option = new Option(location.location, location.location);
                    originSelect.add(option);
                    destinationSelect.add(new Option(location.location, location.location));
                });
            }
        </script>

        <script>
            // For Checker based on the Origin
            document.addEventListener("DOMContentLoaded", function () {
                const checkerSelect = document.getElementById("checker");
                const addCheckerBtn = document.getElementById("addChecker");
                const deleteCheckerBtn = document.getElementById("deleteChecker");

                // Checker options based on origin
                const checkerOptions = {
                    "MANILA": ["", "ALDAY", "ANCHETA", "BERNADOS", "CACHO", "ESGUERRA", "MORENO", "VICTORIANO", "YUMUL", "ZERRUDO"],
                    "BATANES": ["", "SOL", "TIRSO", "VARGAS", "NICK", "JOSIE", "JEN"]
                };

                function getSavedCheckers(origin) {
                    return JSON.parse(localStorage.getItem(`checkers_${origin}`)) || [];
                }

                function saveChecker(origin, name) {
                    let savedCheckers = getSavedCheckers(origin);
                    if (!savedCheckers.includes(name)) {
                        savedCheckers.push(name);
                        localStorage.setItem(`checkers_${origin}`, JSON.stringify(savedCheckers));
                    }
                }

                function deleteChecker(origin, name) {
                    let savedCheckers = getSavedCheckers(origin);
                    let updatedCheckers = savedCheckers.filter(checker => checker !== name);
                    localStorage.setItem(`checkers_${origin}`, JSON.stringify(updatedCheckers));
                }

                function populateCheckerOptions(origin) {
                    checkerSelect.innerHTML = ""; // Clear existing options
                    let options = (checkerOptions[origin] || []).concat(getSavedCheckers(origin));
                    options.forEach(option => {
                        let opt = document.createElement("option");
                        opt.value = option;
                        opt.textContent = option;
                        checkerSelect.appendChild(opt);
                    });
                }

                function updateCheckerOptions() {
                    let origin = document.getElementById("origin")?.value?.toUpperCase();
                    if (origin && checkerOptions[origin]) {
                        populateCheckerOptions(origin);
                    }
                }

                // Add a new checker manually
                addCheckerBtn.addEventListener("click", function () {
                    let origin = document.getElementById("origin")?.value?.toUpperCase();
                    if (!origin || !checkerOptions[origin]) {
                        alert("Please select a valid origin first.");
                        return;
                    }

                    let newChecker = prompt("Enter new checker name:");
                    if (newChecker) {
                        newChecker = newChecker.toUpperCase();
                        saveChecker(origin, newChecker);
                        populateCheckerOptions(origin);
                        checkerSelect.value = newChecker; // Select the newly added checker
                    }
                });

                // Delete selected checker
                deleteCheckerBtn.addEventListener("click", function () {
                    let origin = document.getElementById("origin")?.value?.toUpperCase();
                    let selectedChecker = checkerSelect.value;

                    if (!origin || !checkerOptions[origin]) {
                        alert("Please select a valid origin first.");
                        return;
                    }

                    if (!selectedChecker) {
                        alert("Please select a checker to delete.");
                        return;
                    }

                    let defaultCheckers = checkerOptions[origin] || [];

                    if (defaultCheckers.includes(selectedChecker)) {
                        alert("Cannot delete default checkers.");
                        return;
                    }

                    if (confirm(`Are you sure you want to delete "${selectedChecker}"?`)) {
                        deleteChecker(origin, selectedChecker);
                        populateCheckerOptions(origin);
                    }
                });

                // Update options when origin changes
                document.getElementById("origin")?.addEventListener("change", updateCheckerOptions);

                // Load default options on page load
                updateCheckerOptions();
            });
        </script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<style>
    .bg-emerald-600 {
        background-color: #059669 !important; /* Emerald-600 Hex Code */
    }

    #locationModal {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5); /* Dark background */
        z-index: 50; /* Ensure it appears on top */
        display: flex;
        align-items: center;
        justify-content: center;
        pointer-events: none; /* Prevent clicks when hidden */
        opacity: 0; /* Make it fully hidden */
        transition: opacity 0.3s ease-in-out;
    }

    #locationModal.show {
        pointer-events: auto; /* Enable clicks when shown */
        opacity: 1; /* Make it fully visible */
    }
</style>

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<?php /**PATH C:\xampp\htdocs\SFX-1\resources\views\customer\order.blade.php ENDPATH**/ ?>