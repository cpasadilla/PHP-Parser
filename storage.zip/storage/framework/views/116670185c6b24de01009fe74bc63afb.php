<section>
    <header>
        <h2 class="text-lg font-medium">
            <?php echo e(__('User Page Permission')); ?>

        </h2>

        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            <?php echo e(__("Update user permission per page and operation")); ?>

        </p>
    </header>

    <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
    </form>
    
    <div class="mt-4">
        <?php if(session('status') === 'permissions-updated'): ?>
            <div class="mt-4 p-4 bg-green-50 border border-green-200 text-green-800 rounded">
                <?php echo e(__('User permissions have been updated.')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('status') === 'location-added'): ?>
            <div class="mt-4 p-4 bg-green-50 border border-green-200 text-green-800 rounded">
                <?php echo e(session('message', 'New location has been added.')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('status') === 'checker-added'): ?>
            <div class="mt-4 p-4 bg-green-50 border border-green-200 text-green-800 rounded">
                <?php echo e(session('message', 'New checker has been added.')); ?>

            </div>
        <?php endif; ?>
    </div>

    <?php
        // Fetch all users
        $users = App\Models\User::with(['roles', 'permissions'])->get();
        
        // Define application pages/modules with operations
        $modules = [
            'profile' => [
                'name' => 'Profile Settings',
                'operations' => ['access', 'edit']
            ],
            'dashboard' => [
                'name' => 'Dashboard',
                'operations' => ['access'],
                'pages' => [
                    'ship-graphs' => [
                        'name' => 'Ship Graphs Section',
                        'operations' => ['access']
                    ],
                    'pie-charts' => [
                        'name' => 'Pie Chart Section',
                        'operations' => ['access']
                    ]
                ]
            ],
            'customer' => [
                'name' => 'Customer Management',
                'operations' => ['access', 'create', 'edit', 'delete']
            ],
            'users' => [
                'name' => 'Staff Management',
                'operations' => ['access', 'create', 'edit', 'delete']
            ],
            'history' => [
                'name' => 'History',
                'operations' => ['access']
            ],
            'pricelist' => [
                'name' => 'Price List',
                'operations' => ['access', 'create', 'edit', 'delete']
            ],
            'masterlist' => [
                'name' => 'Master List',
                'operations' => ['access'],
                'pages' => [
                    'ships' => [
                        'name' => 'Ship Management',
                        'operations' => ['access', 'edit', 'delete']
                    ],
                    'voyage' => [
                        'name' => 'Voyage Management',
                        'operations' => ['access', 'edit']
                    ],
                    'list' => [
                        'name' => 'Order List',
                        'operations' => ['access', 'edit', 'delete']
                    ],
                    'customer' => [
                        'name' => 'Customer List',
                        'operations' => ['access', 'edit', 'delete']
                    ],
                    'container' => [
                        'name' => 'Container Management',
                        'operations' => ['access', 'create', 'edit', 'delete']
                    ],
                    'container-details' => [
                        'name' => 'Container Details',
                        'operations' => ['access']
                    ],
                    'parcel' => [
                        'name' => 'Parcel Management',
                        'operations' => ['access']
                    ],
                    'soa' => [
                        'name' => 'Statement of Account',
                        'operations' => ['access', 'create', 'delete']
                    ]
                ]
            ]
        ];
        
        // Current user
        $currentUser = auth()->user();
        $userRole = $currentUser->roles ? strtoupper(trim($currentUser->roles->roles)) : '';
        $isAdmin = in_array($userRole, ['ADMIN', 'ADMINISTRATOR']);
    ?>

    <div class="mb-4 text-sm text-gray-700 dark:text-gray-300">
       Role: <strong><?php echo e($currentUser->roles ? $currentUser->roles->roles : 'No role assigned'); ?></strong>
    </div>

    <form
        method="post"
        action="<?php echo e(route('user-permissions.update')); ?>"
        class="mt-6"
        id="permissions-form"
    >
        <?php echo csrf_field(); ?>

        <?php if($isAdmin): ?>
            <!-- User Tabs -->
            <div x-data="{ activeTab: 0 }" class="mt-4">
                <!-- Tab Navigation - Grid layout that wraps to multiple rows -->
                <div class="mb-4 border-b border-gray-200 dark:border-gray-700">
                    <div class="flex flex-wrap gap-1 pb-1">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $userAdminRole = $user->roles && in_array(strtoupper(trim($user->roles->roles)), ['ADMIN', 'ADMINISTRATOR']);
                                $displayName = $user->fName . ' ' . $user->lName;
                            ?>
                            <button 
                                type="button"
                                @click="activeTab = <?php echo e($index); ?>"
                                :class="{ 'bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-200': activeTab === <?php echo e($index); ?>, 'bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700': activeTab !== <?php echo e($index); ?> }"
                                class="py-2 px-3 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 focus:outline-none transition mb-2"
                                title="<?php echo e($user->fName); ?> <?php echo e($user->lName); ?> (<?php echo e($user->roles ? $user->roles->roles : 'No Role'); ?>)"
                            >
                                <div class="flex items-center">
                                    <span><?php echo e($displayName); ?></span>
                                    <?php if($userAdminRole): ?>
                                        <span class="ml-1 inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200">
                                            A
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                
                <!-- Tab Content -->
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $userAdminRole = $user->roles && in_array(strtoupper(trim($user->roles->roles)), ['ADMIN', 'ADMINISTRATOR']);
                        
                        // Get user permissions from database
                        $userPermissions = [];
                        if ($user->permissions && $user->permissions->pages) {
                            $userPermissions = is_string($user->permissions->pages) ? json_decode($user->permissions->pages, true) : $user->permissions->pages;
                        }
                        
                        // Debug: Add debugging info
                        $debugPermissions = false; // Set to true to enable debugging
                    ?>
                    
                    <div x-show="activeTab === <?php echo e($index); ?>" x-cloak class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
                        <?php if($debugPermissions): ?>
                        <div class="mb-4 p-3 bg-gray-100 dark:bg-gray-700 rounded">
                            <h4 class="font-bold">Debug - User Permissions:</h4>
                            <pre class="text-xs overflow-auto"><?php echo e(json_encode($userPermissions, JSON_PRETTY_PRINT)); ?></pre>
                        </div>
                        <?php endif; ?>
                        <div class="flex flex-col sm:flex-row sm:flex-wrap sm:items-center justify-between mb-4">
                            <div class="mb-2 sm:mb-0">
                                <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">
                                    <?php echo e($user->fName); ?> <?php echo e($user->lName); ?>

                                </h3>
                                <div class="text-sm text-gray-500 dark:text-gray-400">
                                    Email: <?php echo e($user->email); ?> | Role: <?php echo e($user->roles ? $user->roles->roles : 'No Role'); ?>

                                </div>
                            </div>
                            
                            <?php if(!$userAdminRole): ?>
                                <div class="flex flex-wrap gap-2">
                                    <button 
                                        type="button"
                                        onclick="selectAllPermissions(<?php echo e($index); ?>)"
                                        class="inline-flex items-center px-3 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-700 active:bg-green-700 focus:outline-none focus:border-green-700 focus:shadow-outline-green transition ease-in-out duration-150"
                                    >
                                        Select All
                                    </button>
                                    <button 
                                        type="button"
                                        onclick="deselectAllPermissions(<?php echo e($index); ?>)"
                                        class="inline-flex items-center px-3 py-2 bg-yellow-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-yellow-700 active:bg-yellow-700 focus:outline-none focus:border-yellow-700 focus:shadow-outline-yellow transition ease-in-out duration-150"
                                    >
                                        Deselect All
                                    </button>
                                    <button 
                                        type="button"
                                        onclick="deletePermissions('<?php echo e($user->id); ?>')"
                                        class="inline-flex items-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-700 active:bg-red-700 focus:outline-none focus:border-red-700 focus:shadow-outline-red transition ease-in-out duration-150"
                                    >
                                        Delete All Permissions
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                            Module
                                        </th>
                                        <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                            Access
                                        </th>
                                        <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                            Create
                                        </th>
                                        <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                            Edit
                                        </th>
                                        <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                            Delete
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200 dark:divide-gray-700 dark:bg-gray-800">
                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moduleKey => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="<?php echo e($loop->odd ? 'bg-white dark:bg-gray-900' : 'bg-gray-50 dark:bg-gray-800'); ?>">
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">
                                                <?php echo e($module['name']); ?>

                                            </td>
                                            
                                            <?php $__currentLoopData = ['access', 'create', 'edit', 'delete']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                                    <?php if(in_array($operation, $module['operations'])): ?>
                                                        <?php if($userAdminRole): ?>
                                                            <input 
                                                                type="checkbox" 
                                                                name="permissions[<?php echo e($user->id); ?>][<?php echo e($moduleKey); ?>][<?php echo e($operation); ?>]" 
                                                                value="1"
                                                                class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600"
                                                                checked disabled
                                                            >
                                                            <input type="hidden" name="permissions[<?php echo e($user->id); ?>][<?php echo e($moduleKey); ?>][<?php echo e($operation); ?>]" value="1">
                                                        <?php else: ?>
                                                            <input 
                                                                type="checkbox" 
                                                                name="permissions[<?php echo e($user->id); ?>][<?php echo e($moduleKey); ?>][<?php echo e($operation); ?>]" 
                                                                value="1"
                                                                class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600"
                                                                <?php echo e(isset($userPermissions[$moduleKey][$operation]) && $userPermissions[$moduleKey][$operation] ? 'checked' : ''); ?>

                                                            >
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span class="text-gray-400 dark:text-gray-500">—</span>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        
                                        
                                        <?php if(isset($module['pages'])): ?>
                                            <?php $__currentLoopData = $module['pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageKey => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="bg-gray-100 dark:bg-gray-850">
                                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100 pl-10">
                                                        ↳ <?php echo e($page['name']); ?>

                                                    </td>
                                                    
                                                    <?php $__currentLoopData = ['access', 'create', 'edit', 'delete']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="px-6 py-4 whitespace-nowrap text-center">
                                                            <?php if(in_array($operation, $page['operations'])): ?>
                                                                <?php if($userAdminRole): ?>
                                                                    <input 
                                                                        type="checkbox" 
                                                                        name="permissions[<?php echo e($user->id); ?>][<?php echo e($moduleKey); ?>][pages][<?php echo e($pageKey); ?>][<?php echo e($operation); ?>]" 
                                                                        value="1"
                                                                        class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600"
                                                                        checked disabled
                                                                    >
                                                                    <input type="hidden" name="permissions[<?php echo e($user->id); ?>][<?php echo e($moduleKey); ?>][pages][<?php echo e($pageKey); ?>][<?php echo e($operation); ?>]" value="1">
                                                                <?php else: ?>
                                                                    <input 
                                                                        type="checkbox" 
                                                                        name="permissions[<?php echo e($user->id); ?>][<?php echo e($moduleKey); ?>][pages][<?php echo e($pageKey); ?>][<?php echo e($operation); ?>]" 
                                                                        value="1"
                                                                        class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600"
                                                                        <?php echo e(isset($userPermissions[$moduleKey]['pages'][$pageKey][$operation]) && $userPermissions[$moduleKey]['pages'][$pageKey][$operation] ? 'checked' : ''); ?>

                                                                    >
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <span class="text-gray-400 dark:text-gray-500">—</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="flex items-center gap-4 mt-4">
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'primary','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'primary','type' => 'submit']); ?>
                    <?php echo e(__('Save Permissions')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'secondary','type' => 'button','id' => 'add-location-btn']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'secondary','type' => 'button','id' => 'add-location-btn']); ?>
                    <?php echo e(__('Add New Location')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'secondary','type' => 'button','id' => 'add-checker-btn']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'secondary','type' => 'button','id' => 'add-checker-btn']); ?>
                    <?php echo e(__('Add New Checker')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            </div>
            
            <?php if(session('status') === 'permissions-updated'): ?>
                <div class="mt-4 p-4 bg-green-50 border border-green-200 text-green-800 rounded">
                    <?php echo e(__('User permissions have been updated.')); ?>

                </div>
            <?php endif; ?>
            
            <?php if(session('status') === 'location-added'): ?>
                <div class="mt-4 p-4 bg-green-50 border border-green-200 text-green-800 rounded">
                    <?php echo e(__('New location has been added successfully.')); ?>

                </div>
            <?php endif; ?>
            
            <?php if(session('error')): ?>
                <div class="mt-4 p-4 bg-red-50 border border-red-200 text-red-800 rounded">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 rounded-lg p-4 dark:bg-yellow-900/30 dark:border-yellow-800 dark:text-yellow-200">
                <p>You need administrator privileges to manage user permissions. Your current role is <strong><?php echo e($currentUser->roles ? $currentUser->roles->roles : 'No role assigned'); ?></strong>.</p>
            </div>
        <?php endif; ?>
    </form>

    <!-- Delete permission confirmation modal -->
    <div id="delete-modal" class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-lg shadow-xl p-6 max-w-md w-full dark:bg-gray-800">
            <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Confirm Delete</h3>
            <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
                Are you sure you want to delete all permissions for this user? They will only be able to access their profile page.
            </p>
            <div class="mt-4 flex justify-end">
                <button 
                    type="button" 
                    onclick="closeDeleteModal()"
                    class="inline-flex items-center px-4 py-2 bg-gray-300 border border-transparent rounded-md font-semibold text-xs text-gray-800 uppercase tracking-widest hover:bg-gray-400 active:bg-gray-400 focus:outline-none focus:border-gray-400 focus:shadow-outline-gray transition ease-in-out duration-150 mr-2"
                >
                    Cancel
                </button>
                <form id="delete-form" method="post" action="<?php echo e(route('user-permissions.delete')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="hidden" id="user_id_to_delete" name="user_id">
                    <button 
                        type="submit"
                        class="inline-flex items-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-700 active:bg-red-700 focus:outline-none focus:border-red-700 focus:shadow-outline-red transition ease-in-out duration-150"
                    >
                        Delete All
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Add Location Modal -->
    <div id="add-location-modal" class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-lg shadow-xl p-6 max-w-md w-full dark:bg-gray-800">
            <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Add New Location</h3>
            <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
                Enter the name of the new location to be added to the database.
            </p>
            <form id="add-location-form" method="post" action="<?php echo e(route('locations.store')); ?>" class="mt-4" onsubmit="return validateLocationForm()">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="location" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Location Name</label>
                    <input 
                        type="text" 
                        id="location" 
                        name="location" 
                        required 
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        placeholder="Enter location name"
                        oninput="validateLocationName(this)"
                    >
                    <p id="location-error" class="mt-1 text-sm text-red-600 hidden"></p>
                </div>
                <div class="mt-4 flex justify-end">
                    <button 
                        type="button" 
                        onclick="closeLocationModal()"
                        class="inline-flex items-center px-4 py-2 bg-gray-300 border border-transparent rounded-md font-semibold text-xs text-gray-800 uppercase tracking-widest hover:bg-gray-400 active:bg-gray-400 focus:outline-none focus:border-gray-400 focus:shadow-outline-gray transition ease-in-out duration-150 mr-2"
                    >
                        Cancel
                    </button>
                    <button 
                        type="submit"
                        class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-700 focus:outline-none focus:border-indigo-700 focus:shadow-outline-indigo transition ease-in-out duration-150"
                    >
                        Add Location
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Checker Modal -->
    <div id="add-checker-modal" class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-lg shadow-xl p-6 max-w-md w-full dark:bg-gray-800">
            <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Add New Checker</h3>
            <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
                Enter the name of the new checker and select their location.
            </p>
            <form id="add-checker-form" method="post" action="<?php echo e(route('checkers.store')); ?>" class="mt-4" onsubmit="return validateCheckerForm()">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="checker-location" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Location</label>
                    <select 
                        id="checker-location" 
                        name="location" 
                        required 
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                    >
                        <option value="">Select a location</option>
                        <?php
                            // Get locations from the database
                            $locations = DB::table('locations')->orderBy('location')->pluck('location');
                        ?>
                        
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location); ?>"><?php echo e($location); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mt-4">
                    <label for="checker-name" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Checker Name</label>
                    <input 
                        type="text" 
                        id="checker-name" 
                        name="name" 
                        required 
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        placeholder="Enter checker name"
                        oninput="validateCheckerName(this)"
                    >
                    <p id="checker-error" class="mt-1 text-sm text-red-600 hidden"></p>
                </div>
                <div class="mt-4 flex justify-end">
                    <button 
                        type="button" 
                        onclick="closeCheckerModal()"
                        class="inline-flex items-center px-4 py-2 bg-gray-300 border border-transparent rounded-md font-semibold text-xs text-gray-800 uppercase tracking-widest hover:bg-gray-400 active:bg-gray-400 focus:outline-none focus:border-gray-400 focus:shadow-outline-gray transition ease-in-out duration-150 mr-2"
                    >
                        Cancel
                    </button>
                    <button 
                        type="submit"
                        class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-700 focus:outline-none focus:border-blue-700 focus:shadow-outline-blue transition ease-in-out duration-150"
                    >
                        Add Checker
                    </button>
                </div>
            </form>
        </div>
    </div>

    <style>
    [x-cloak] { display: none !important; }
    </style>

    <script>
        function selectAllPermissions(userIndex) {
            // Get all checkboxes in the current user's tab that are not disabled
            const userTab = document.querySelector(`[x-show="activeTab === ${userIndex}"]`);
            const checkboxes = userTab.querySelectorAll('input[type="checkbox"]:not([disabled])');
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = true;
            });
            
            // Show feedback
            showPermissionFeedback('All permissions have been selected', 'success');
        }

        function deselectAllPermissions(userIndex) {
            // Get all checkboxes in the current user's tab that are not disabled
            const userTab = document.querySelector(`[x-show="activeTab === ${userIndex}"]`);
            const checkboxes = userTab.querySelectorAll('input[type="checkbox"]:not([disabled])');
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = false;
            });
            
            // Show feedback
            showPermissionFeedback('All permissions have been deselected', 'warning');
        }

        function showPermissionFeedback(message, type) {
            // Remove any existing feedback
            const existingFeedback = document.querySelector('.permission-feedback');
            if (existingFeedback) {
                existingFeedback.remove();
            }
            
            // Create feedback element
            const feedback = document.createElement('div');
            feedback.className = `permission-feedback mt-2 p-2 rounded text-sm ${type === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-yellow-100 text-yellow-800 border border-yellow-200'}`;
            feedback.textContent = message;
            
            // Insert after the buttons
            const activeTab = document.querySelector('[x-show="activeTab === ' + document.querySelector('[x-data]').__x.$data.activeTab + '"]');
            const buttonContainer = activeTab.querySelector('.flex.flex-col.sm\\:flex-row');
            buttonContainer.parentNode.insertBefore(feedback, buttonContainer.nextSibling);
            
            // Remove feedback after 3 seconds
            setTimeout(() => {
                if (feedback.parentNode) {
                    feedback.remove();
                }
            }, 3000);
        }

        function deletePermissions(userId) {
            document.getElementById('user_id_to_delete').value = userId;
            document.getElementById('delete-modal').classList.remove('hidden');
        }

        function closeDeleteModal() {
            document.getElementById('delete-modal').classList.add('hidden');
        }

        // Close the modal if clicking outside of it
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('delete-modal');
            if (event.target === modal) {
                closeDeleteModal();
            }
        });

        // Location name validation function
        function validateLocationName(input) {
            const value = input.value;
            const errorElement = document.getElementById('location-error');
            const submitButton = document.querySelector('#add-location-form button[type="submit"]');
            
            // Reset error state
            errorElement.classList.add('hidden');
            errorElement.textContent = '';
            input.classList.remove('border-red-500');
            submitButton.disabled = false;
            
            // Check for symbols (anything that's not a letter, number, or space)
            if (/[^a-zA-Z0-9\s]/.test(value)) {
                errorElement.textContent = 'Symbols are not allowed in location name';
                errorElement.classList.remove('hidden');
                input.classList.add('border-red-500');
                submitButton.disabled = true;
                return false;
            }
            
            // Check for numbers
            if (/[0-9]/.test(value)) {
                errorElement.textContent = 'Numbers are not allowed in location name';
                errorElement.classList.remove('hidden');
                input.classList.add('border-red-500');
                submitButton.disabled = true;
                return false;
            }
            
            // If we got here, input is valid
            return true;
        }

        // Location modal functions
        document.getElementById('add-location-btn').addEventListener('click', function() {
            document.getElementById('add-location-modal').classList.remove('hidden');
        });

        function closeLocationModal() {
            // Hide the modal
            document.getElementById('add-location-modal').classList.add('hidden');
            
            // Clear the location name input field
            const locationInput = document.getElementById('location');
            if (locationInput) {
                locationInput.value = '';
                
                // Reset any error states
                const errorElement = document.getElementById('location-error');
                if (errorElement) {
                    errorElement.classList.add('hidden');
                    errorElement.textContent = '';
                }
                locationInput.classList.remove('border-red-500');
                
                // Re-enable the submit button if it was disabled
                const submitButton = document.querySelector('#add-location-form button[type="submit"]');
                if (submitButton) {
                    submitButton.disabled = false;
                }
            }
        }

        // Close the location modal if clicking outside of it
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('add-location-modal');
            if (event.target === modal) {
                closeLocationModal();
            }
        });

        // Validate the location form before submission
        function validateLocationForm() {
            const locationInput = document.getElementById('location');
            return validateLocationName(locationInput);
        }
        
        // Checker modal functions
        document.getElementById('add-checker-btn').addEventListener('click', function() {
            document.getElementById('add-checker-modal').classList.remove('hidden');
        });

        function closeCheckerModal() {
            // Hide the modal
            document.getElementById('add-checker-modal').classList.add('hidden');
            
            // Clear the checker name input field and reset the location dropdown
            const checkerNameInput = document.getElementById('checker-name');
            const checkerLocationSelect = document.getElementById('checker-location');
            
            if (checkerNameInput) {
                checkerNameInput.value = '';
                checkerNameInput.classList.remove('border-red-500');
                document.getElementById('checker-error').classList.add('hidden');
                document.getElementById('checker-error').textContent = '';
            }
            
            if (checkerLocationSelect) {
                checkerLocationSelect.selectedIndex = 0;
            }
        }

        // Close the checker modal if clicking outside of it
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('add-checker-modal');
            if (event.target === modal) {
                closeCheckerModal();
            }
        });

        // Checker name validation function
        function validateCheckerName(input) {
            const value = input.value;
            const errorElement = document.getElementById('checker-error');
            const submitButton = document.querySelector('#add-checker-form button[type="submit"]');
            
            // Reset error state
            errorElement.classList.add('hidden');
            errorElement.textContent = '';
            input.classList.remove('border-red-500');
            submitButton.disabled = false;
            
            // Check for symbols (anything that's not a letter, number, or space)
            if (/[^a-zA-Z\s]/.test(value)) {
                errorElement.classList.remove('hidden');
                errorElement.textContent = 'Checker name cannot contain numbers or symbols. Only letters and spaces are allowed.';
                input.classList.add('border-red-500');
                submitButton.disabled = true;
                return false;
            }
            
            // If we got here, input is valid
            return true;
        }

        // Validate the checker form before submission
        function validateCheckerForm() {
            const checkerNameInput = document.getElementById('checker-name');
            const checkerLocationSelect = document.getElementById('checker-location');
            const errorElement = document.getElementById('checker-error');
            
            // Check if location is selected
            if (checkerLocationSelect.value === '') {
                errorElement.classList.remove('hidden');
                errorElement.textContent = 'Please select a location for the checker.';
                return false;
            }
            
            return validateCheckerName(checkerNameInput);
        }
    </script>
</section><?php /**PATH C:\xampp\htdocs\SFX-1\resources\views\profile\partials\update-permission-form.blade.php ENDPATH**/ ?>