<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-2xl font-bold text-gray-800 dark:text-gray-200">
                <button onclick="window.location.href='<?php echo e(route('history')); ?>';" class="px-4 py-2 text-blue-600 rounded-md hover:text-blue-700 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600">
                    ←
                </button>
                <?php echo e(__('History')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1 dark:text-gray-300">
        <ul class="flex border-b mb-4 dark:border-gray-700">
            <li class="-mb-px mr-1">
                <a class="tab-link bg-white inline-block border-l border-t border-r rounded-t py-2 px-4 text-blue-700 font-semibold dark:bg-gray-800 dark:text-blue-400" href="#user-activity" onclick="showTab('user-activity')">User Activity</a>
            </li>
            <li class="mr-1">
                <a class="tab-link bg-white inline-block py-2 px-4 text-blue-500 hover:text-blue-800 font-semibold dark:bg-gray-800 dark:text-blue-300 dark:hover:text-blue-500" href="#order-update-logs" onclick="showTab('order-update-logs')">Order Update Logs</a>
            </li>
            <li class="mr-1">
                <a class="tab-link bg-white inline-block py-2 px-4 text-blue-500 hover:text-blue-800 font-semibold dark:bg-gray-800 dark:text-blue-300 dark:hover:text-blue-500" href="#order-delete-logs" onclick="showTab('order-delete-logs')">Delete BL History</a>
            </li>
        </ul>

        <div id="user-activity" class="tab-content mt-4">
            <h3 class="text-lg font-semibold mb-4 dark:text-gray-200">User Activity</h3>
            <form method="GET" action="<?php echo e(route('history')); ?>" class="flex flex-wrap gap-4 mb-4">
                <input type="hidden" name="tab" value="user-activity">
                <select name="name" class="border rounded px-4 py-2 flex-grow dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300">
                    <option value="">All Users</option>
                    <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->name); ?>" <?php echo e(request('name') == $user->name ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700">Filter</button>
            </form>
            <div class="overflow-x-auto">
                <table class="table-auto w-full mt-4 border-collapse border border-gray-200 dark:border-gray-700">
                    <thead>
                        <tr class="bg-gray-100 dark:bg-gray-800">
                            <th class="px-4 py-2 border dark:border-gray-700">Name</th>
                            <th class="px-4 py-2 border dark:border-gray-700">IP Address</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Last Activity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $userActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($activity->name); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($activity->ip_address); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e(date('Y-m-d H:i:s', $activity->last_activity)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                <?php echo e($userActivities->appends(['tab' => 'user-activity', 'name' => request('name')])->links()); ?>

            </div>
        </div>

        <div id="order-update-logs" class="tab-content mt-4 hidden">
            <h3 class="text-lg font-semibold mb-4 dark:text-gray-200">Order Update Logs</h3>
            <form method="GET" action="<?php echo e(route('history')); ?>" class="flex flex-wrap gap-4 mb-4">
                <input type="hidden" name="tab" value="order-update-logs">
                <select name="updated_by" class="border rounded px-4 py-2 flex-grow dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300">
                    <option value="">All Users</option>
                    <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->name); ?>" <?php echo e(request('updated_by') == $user->name ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="field_name" class="border rounded px-4 py-2 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300">
                    <option value="">All Fields</option>
                    <option value="OR" <?php echo e(request('field_name') == 'OR' ? 'selected' : ''); ?>>OR Number</option>
                    <option value="AR" <?php echo e(request('field_name') == 'AR' ? 'selected' : ''); ?>>AR Number</option>
                    <option value="freight" <?php echo e(request('field_name') == 'freight' ? 'selected' : ''); ?>>Freight</option>
                    <option value="value" <?php echo e(request('field_name') == 'value' ? 'selected' : ''); ?>>Value</option>
                    <option value="valuation" <?php echo e(request('field_name') == 'valuation' ? 'selected' : ''); ?>>Valuation</option>
                    <option value="wharfage" <?php echo e(request('field_name') == 'wharfage' ? 'selected' : ''); ?>>Wharfage</option>
                    <option value="other" <?php echo e(request('field_name') == 'other' ? 'selected' : ''); ?>>Other</option>
                    <option value="discount" <?php echo e(request('field_name') == 'discount' ? 'selected' : ''); ?>>Discount</option>
                    <option value="bir" <?php echo e(request('field_name') == 'bir' ? 'selected' : ''); ?>>BIR</option>
                    <option value="totalAmount" <?php echo e(request('field_name') == 'totalAmount' ? 'selected' : ''); ?>>Total Amount</option>
                    <option value="containerNum" <?php echo e(request('field_name') == 'containerNum' ? 'selected' : ''); ?>>Container Number</option>
                    <option value="remark" <?php echo e(request('field_name') == 'remark' ? 'selected' : ''); ?>>Remark</option>
                    <option value="note" <?php echo e(request('field_name') == 'note' ? 'selected' : ''); ?>>Note</option>
                    <option value="checkName" <?php echo e(request('field_name') == 'checkName' ? 'selected' : ''); ?>>Checker Name</option>
                    <option value="cargoType" <?php echo e(request('field_name') == 'cargoType' ? 'selected' : ''); ?>>Cargo Type</option>
                    <option value="blStatus" <?php echo e(request('field_name') == 'blStatus' ? 'selected' : ''); ?>>BL Status</option>
                    <option value="image" <?php echo e(request('field_name') == 'image' ? 'selected' : ''); ?>>Image</option>
                </select>
                <select name="action_type" class="border rounded px-4 py-2 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300">
                    <option value="">All Actions</option>
                    <option value="update" <?php echo e(request('action_type') == 'update' ? 'selected' : ''); ?>>Update</option>
                    <option value="create" <?php echo e(request('action_type') == 'create' ? 'selected' : ''); ?>>Create</option>
                    <option value="delete" <?php echo e(request('action_type') == 'delete' ? 'selected' : ''); ?>>Delete</option>
                </select>
                <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700">Filter</button>
            </form>
            <div class="overflow-x-auto">
                <table class="table-auto w-full mt-4 border-collapse border border-gray-200 dark:border-gray-700">
                    <thead>
                        <tr class="bg-gray-100 dark:bg-gray-800">
                            <th class="px-4 py-2 border dark:border-gray-700" hidden>Order ID</th>
                            <th class="px-4 py-2 border dark:border-gray-700">BL #</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Ship</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Voyage</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Field Updated</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Old Value</th>
                            <th class="px-4 py-2 border dark:border-gray-700">New Value</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Action</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Updated By</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Updated At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orderUpdateLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="border px-4 py-2 dark:border-gray-700" hidden><?php echo e($log->order_id); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->bl_number); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->ship_name); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->voyage_number); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center">
                                    <?php if($log->field_name): ?>
                                        <span class="px-2 py-1 text-xs font-semibold rounded bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $log->field_name))); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="text-gray-500 dark:text-gray-400">General Update</span>
                                    <?php endif; ?>
                                </td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center max-w-xs">
                                    <?php if($log->old_value !== null): ?>
                                        <div class="truncate" title="<?php echo e($log->old_value); ?>">
                                            <?php if(strlen($log->old_value) > 50): ?>
                                                <?php echo e(substr($log->old_value, 0, 50)); ?>...
                                            <?php else: ?>
                                                <?php echo e($log->old_value); ?>

                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-gray-400 dark:text-gray-500 italic">empty</span>
                                    <?php endif; ?>
                                </td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center max-w-xs">
                                    <?php if($log->new_value !== null): ?>
                                        <div class="truncate" title="<?php echo e($log->new_value); ?>">
                                            <?php if(strlen($log->new_value) > 50): ?>
                                                <?php echo e(substr($log->new_value, 0, 50)); ?>...
                                            <?php else: ?>
                                                <?php echo e($log->new_value); ?>

                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-gray-400 dark:text-gray-500 italic">empty</span>
                                    <?php endif; ?>
                                </td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center">
                                    <?php if($log->action_type === 'update'): ?>
                                        <span class="px-2 py-1 text-xs font-semibold rounded bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Update</span>
                                    <?php elseif($log->action_type === 'create'): ?>
                                        <span class="px-2 py-1 text-xs font-semibold rounded bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">Create</span>
                                    <?php elseif($log->action_type === 'delete'): ?>
                                        <span class="px-2 py-1 text-xs font-semibold rounded bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">Delete</span>
                                    <?php else: ?>
                                        <span class="px-2 py-1 text-xs font-semibold rounded bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"><?php echo e(ucfirst($log->action_type)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->updated_by); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->updated_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                <?php echo e($orderUpdateLogs->appends(['tab' => 'order-update-logs', 'updated_by' => request('updated_by'), 'field_name' => request('field_name'), 'action_type' => request('action_type')])->links()); ?>

            </div>
        </div>

        <div id="order-delete-logs" class="tab-content mt-4 hidden">
            <h3 class="text-lg font-semibold mb-4 dark:text-gray-200">Delete BL History</h3>
            <form method="GET" action="<?php echo e(route('history')); ?>" class="flex flex-wrap gap-4 mb-4">
                <input type="hidden" name="tab" value="order-delete-logs">
                <select name="deleted_by" class="border rounded px-4 py-2 flex-grow dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300">
                    <option value="">All Users</option>
                    <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->name); ?>" <?php echo e(request('deleted_by') == $user->name ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="restore_status" class="border rounded px-4 py-2 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300">
                    <option value="">All Status</option>
                    <option value="deleted" <?php echo e(request('restore_status') == 'deleted' ? 'selected' : ''); ?>>Deleted Only</option>
                    <option value="restored" <?php echo e(request('restore_status') == 'restored' ? 'selected' : ''); ?>>Restored Only</option>
                </select>
                <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700">Filter</button>
            </form>
            <div class="overflow-x-auto">
                <table class="table-auto w-full mt-4 border-collapse border border-gray-200 dark:border-gray-700">
                    <thead>
                        <tr class="bg-gray-100 dark:bg-gray-800">
                            <th class="px-4 py-2 border dark:border-gray-700">BL #</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Ship</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Voyage</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Shipper</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Consignee</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Total Amount</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Deleted By</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Deleted At</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Status</th>
                            <th class="px-4 py-2 border dark:border-gray-700">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orderDeleteLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->bl_number); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->ship_name); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->voyage_number); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->shipper_name); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->consignee_name); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center">₱<?php echo e(number_format($log->total_amount ?? 0, 2)); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->deleted_by); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center"><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center">
                                    <?php if($log->restored_at): ?>
                                        <span class="text-green-600 dark:text-green-400 font-semibold">
                                            ✓ Restored
                                        </span>
                                        <br>
                                        <small class="text-gray-500 dark:text-gray-400">
                                            <?php echo e($log->restored_at->format('Y-m-d H:i:s')); ?>

                                            <br>by <?php echo e($log->restored_by); ?>

                                        </small>
                                    <?php else: ?>
                                        <span class="text-red-600 dark:text-red-400 font-semibold">
                                            ✗ Deleted
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="border px-4 py-2 dark:border-gray-700 text-center">
                                    <?php if(!$log->restored_at): ?>
                                        <form action="<?php echo e(route('masterlist.restore-order', $log->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure you want to restore this order? This will create a new BL with the same data.');">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="px-3 py-1 bg-green-500 text-white text-sm rounded hover:bg-green-600 dark:bg-green-600 dark:hover:bg-green-700">
                                                🔄 Restore
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('masterlist.view-bl', ['shipNum' => $log->restoredOrder->shipNum, 'voyageNum' => $log->restoredOrder->voyageNum, 'orderId' => $log->restored_order_id])); ?>" class="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 inline-block">
                                            👁️ View Restored
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="border px-4 py-8 dark:border-gray-700 text-center text-gray-500 dark:text-gray-400">
                                    No deleted orders found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                <?php echo e($orderDeleteLogs->appends(['tab' => 'order-delete-logs', 'deleted_by' => request('deleted_by'), 'restore_status' => request('restore_status')])->links()); ?>

            </div>
        </div>
    </div>

    <style>
        .truncate {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .max-w-xs {
            max-width: 20rem;
        }
        
        /* Better contrast for badges */
        .bg-blue-100 { background-color: #dbeafe; }
        .text-blue-800 { color: #1e40af; }
        .bg-green-100 { background-color: #dcfce7; }
        .text-green-800 { color: #166534; }
        .bg-red-100 { background-color: #fee2e2; }
        .text-red-800 { color: #991b1b; }
        .bg-gray-100 { background-color: #f3f4f6; }
        .text-gray-800 { color: #1f2937; }
        
        /* Dark mode badge colors */
        .dark .bg-blue-900 { background-color: #1e3a8a; }
        .dark .text-blue-200 { color: #bfdbfe; }
        .dark .bg-green-900 { background-color: #14532d; }
        .dark .text-green-200 { color: #bbf7d0; }
        .dark .bg-red-900 { background-color: #7f1d1d; }
        .dark .text-red-200 { color: #fecaca; }
        .dark .bg-gray-900 { background-color: #111827; }
        .dark .text-gray-200 { color: #e5e7eb; }
        
        /* Improved table responsiveness */
        .table-auto {
            table-layout: auto;
        }
        
        .overflow-x-auto {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        
        /* Better form styling */
        .flex-wrap.gap-4 > * {
            min-width: 150px;
        }
        
        .flex-wrap.gap-4 > select:first-of-type {
            flex-grow: 1;
            min-width: 200px;
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const urlParams = new URLSearchParams(window.location.search);
            const activeTab = urlParams.get('tab') || 'user-activity';
            showTab(activeTab);
        });

        function showTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.add('hidden');
            });
            document.getElementById(tabId).classList.remove('hidden');

            document.querySelectorAll('.tab-link').forEach(link => {
                link.classList.remove('text-blue-700', 'border-l', 'border-t', 'border-r', 'rounded-t');
                link.classList.add('text-blue-500', 'hover:text-blue-800', 'dark:text-blue-300', 'dark:hover:text-blue-500');
            });
            document.querySelector(`[href="#${tabId}"]`).classList.add('text-blue-700', 'border-l', 'border-t', 'border-r', 'rounded-t', 'dark:text-blue-400');
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\SFX-1\resources\views\history\index.blade.php ENDPATH**/ ?>